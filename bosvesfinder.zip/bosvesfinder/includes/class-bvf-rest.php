<?php
/**
 * REST API routes for tracking and fleet data.
 *
 * @package BosVesFinder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers custom REST routes under /bosvesfinder/v1.
 */
class BVF_REST {

	/**
	 * Seconds without a position before a vessel is considered offline.
	 *
	 * @var int
	 */
	private const OFFLINE_AFTER_SECONDS = 600;

	/**
	 * Speed above this (knots) counts as moving when online.
	 *
	 * @var float
	 */
	private const MOVING_SPEED_KNOTS = 0.5;

	/**
	 * Hook into REST API initialization.
	 */
	public function register_hooks() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		add_filter( 'rest_post_dispatch', array( $this, 'add_security_headers' ), 10, 3 );
	}

	/**
	 * Harden JSON responses for this namespace.
	 *
	 * @param WP_REST_Response $response Result.
	 * @param WP_REST_Server   $server   Server.
	 * @param WP_REST_Request  $request  Request.
	 * @return WP_REST_Response
	 */
	public function add_security_headers( $response, $server, $request ) {
		unset( $server );
		if ( ! $response instanceof WP_REST_Response || ! $request instanceof WP_REST_Request ) {
			return $response;
		}
		$route = $request->get_route();
		if ( ! is_string( $route ) || strpos( $route, '/bosvesfinder/' ) === false ) {
			return $response;
		}
		$response->header( 'X-Content-Type-Options', 'nosniff' );
		$response->header( 'X-Frame-Options', 'SAMEORIGIN' );
		return $response;
	}

	/**
	 * Register all routes.
	 */
	public function register_routes() {
		register_rest_route(
			'bosvesfinder/v1',
			'/fleet/live',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_fleet_live' ),
				'permission_callback' => array( $this, 'can_view_fleet' ),
			)
		);

		register_rest_route(
			'bosvesfinder/v1',
			'/fleet/tracks',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_fleet_tracks' ),
				'permission_callback' => array( $this, 'can_view_fleet' ),
				'args'                => array(
					'hours' => array(
						'description' => __( 'Hours of history per active trip.', 'bosvesfinder' ),
						'type'        => 'integer',
						'default'     => 48,
						'minimum'     => 1,
						'maximum'     => 168,
					),
				),
			)
		);

		register_rest_route(
			'bosvesfinder/v1',
			'/vessels',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_vessels' ),
					'permission_callback' => array( $this, 'can_view_fleet' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_vessel' ),
					'permission_callback' => array( $this, 'can_manage_fleet' ),
					'args'                => $this->vessel_create_args(),
				),
			)
		);

		register_rest_route(
			'bosvesfinder/v1',
			'/trips',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_trips_rest' ),
					'permission_callback' => array( $this, 'can_view_fleet' ),
					'args'                => $this->list_trips_args(),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_trip' ),
					'permission_callback' => array( $this, 'can_manage_fleet' ),
					'args'                => $this->trip_create_args(),
				),
			)
		);

		register_rest_route(
			'bosvesfinder/v1',
			'/trips/mine/active',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_my_active_trip' ),
				'permission_callback' => array( $this, 'can_submit_tracking' ),
			)
		);

		register_rest_route(
			'bosvesfinder/v1',
			'/trips/(?P<id>\d+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_trip_rest' ),
				'permission_callback' => array( $this, 'can_view_fleet' ),
			)
		);

		register_rest_route(
			'bosvesfinder/v1',
			'/trips/(?P<id>\d+)/positions',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'post_trip_position' ),
				'permission_callback' => array( $this, 'can_post_position_for_trip' ),
				'args'                => $this->position_args(),
			)
		);

		register_rest_route(
			'bosvesfinder/v1',
			'/trips/(?P<id>\d+)/complete',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'complete_trip' ),
				'permission_callback' => array( $this, 'can_complete_trip' ),
			)
		);

		register_rest_route(
			'bosvesfinder/v1',
			'/alerts/sos',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'post_sos_alert' ),
				'permission_callback' => array( $this, 'can_post_sos' ),
				'args'                => array(
					'trip_id' => array(
						'required' => true,
						'type'     => 'integer',
					),
					'note'    => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);
	}

	/**
	 * @return bool|WP_Error
	 */
	public function can_view_fleet() {
		if ( ! is_user_logged_in() || ! current_user_can( BVF_Roles::CAP_VIEW_FLEET ) ) {
			return new WP_Error( 'bvf_forbidden', __( 'Fleet map access required.', 'bosvesfinder' ), array( 'status' => 403 ) );
		}
		return true;
	}

	/**
	 * @return bool|WP_Error
	 */
	public function can_manage_fleet() {
		if ( ! is_user_logged_in() || ! current_user_can( BVF_Roles::CAP_MANAGE_FLEET ) ) {
			return new WP_Error( 'bvf_forbidden', __( 'Fleet management permission required.', 'bosvesfinder' ), array( 'status' => 403 ) );
		}
		return true;
	}

	/**
	 * @return bool|WP_Error
	 */
	public function can_submit_tracking() {
		if ( ! is_user_logged_in() || ! current_user_can( BVF_Roles::CAP_SUBMIT_TRACKING ) ) {
			return new WP_Error( 'bvf_forbidden', __( 'Tracking permission required.', 'bosvesfinder' ), array( 'status' => 403 ) );
		}
		return true;
	}

	/**
	 * Permission for POST /trips/{id}/positions.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool|WP_Error
	 */
	public function can_post_position_for_trip( WP_REST_Request $request ) {
		$check = $this->can_submit_tracking();
		if ( is_wp_error( $check ) ) {
			return $check;
		}
		$trip_id = (int) $request['id'];
		if ( ! $this->user_is_trip_captain( $trip_id ) ) {
			return new WP_Error( 'bvf_forbidden', __( 'You are not the captain for this trip.', 'bosvesfinder' ), array( 'status' => 403 ) );
		}
		return true;
	}

	/**
	 * Captain or fleet manager may complete a trip.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool|WP_Error
	 */
	public function can_complete_trip( WP_REST_Request $request ) {
		if ( ! is_user_logged_in() ) {
			return new WP_Error( 'bvf_forbidden', __( 'Authentication required.', 'bosvesfinder' ), array( 'status' => 403 ) );
		}
		$trip_id = (int) $request['id'];
		if ( current_user_can( BVF_Roles::CAP_MANAGE_FLEET ) ) {
			return true;
		}
		if ( current_user_can( BVF_Roles::CAP_SUBMIT_TRACKING ) && $this->user_is_trip_captain( $trip_id ) ) {
			return true;
		}
		return new WP_Error( 'bvf_forbidden', __( 'You cannot complete this trip.', 'bosvesfinder' ), array( 'status' => 403 ) );
	}

	/**
	 * SOS: captain must match trip.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool|WP_Error
	 */
	public function can_post_sos( WP_REST_Request $request ) {
		$check = $this->can_submit_tracking();
		if ( is_wp_error( $check ) ) {
			return $check;
		}
		$trip_id = (int) $request->get_param( 'trip_id' );
		if ( ! $this->user_is_trip_captain( $trip_id ) ) {
			return new WP_Error( 'bvf_forbidden', __( 'You are not the captain for this trip.', 'bosvesfinder' ), array( 'status' => 403 ) );
		}
		return true;
	}

	/**
	 * Record an SOS alert and notify operations by email.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function post_sos_alert( WP_REST_Request $request ) {
		$uid = get_current_user_id();
		$rl  = BVF_Rate_Limit::allow_or_error(
			'sos',
			$uid,
			(int) apply_filters( 'bvf_rate_limit_sos_max', 5 ),
			(int) apply_filters( 'bvf_rate_limit_sos_window', 600 )
		);
		if ( is_wp_error( $rl ) ) {
			return $rl;
		}

		global $wpdb;
		$trip_id = (int) $request->get_param( 'trip_id' );
		$trips   = $wpdb->prefix . 'bvf_trips';
		$trip    = $wpdb->get_row( $wpdb->prepare( "SELECT id, vessel_id, status FROM {$trips} WHERE id = %d", $trip_id ), ARRAY_A );
		if ( ! $trip ) {
			return new WP_Error( 'bvf_not_found', __( 'Trip not found.', 'bosvesfinder' ), array( 'status' => 404 ) );
		}

		$note    = sanitize_text_field( (string) $request->get_param( 'note' ) );
		$payload = wp_json_encode(
			array(
				'note'       => $note,
				'user_agent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
			)
		);

		$alerts = $wpdb->prefix . 'bvf_alerts';
		$now    = current_time( 'mysql' );
		$ok     = $wpdb->insert(
			$alerts,
			array(
				'alert_type' => 'sos',
				'severity'   => 'critical',
				'trip_id'    => $trip_id,
				'vessel_id'  => (int) $trip['vessel_id'],
				'user_id'    => get_current_user_id(),
				'payload'    => $payload,
				'created_at' => $now,
			),
			array( '%s', '%s', '%d', '%d', '%d', '%s', '%s' )
		);

		if ( ! $ok ) {
			return new WP_Error( 'bvf_db_error', __( 'Could not record SOS.', 'bosvesfinder' ), array( 'status' => 500 ) );
		}

		$alert_id = (int) $wpdb->insert_id;
		BVF_Notifications::notify_sos( $alert_id, $trip_id, (int) $trip['vessel_id'] );
		do_action( 'bvf_sos_recorded', $alert_id, $trip_id, (int) $trip['vessel_id'] );

		return rest_ensure_response(
			array(
				'id' => $alert_id,
			)
		);
	}

	/**
	 * Latest position per active trip for the fleet map.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_fleet_live() {
		$cached = BVF_Fleet_Cache::get();
		if ( false !== $cached ) {
			return rest_ensure_response( $cached );
		}

		$out = $this->query_fleet_live_payload();
		if ( is_wp_error( $out ) ) {
			return $out;
		}

		BVF_Fleet_Cache::set( $out );
		return rest_ensure_response( $out );
	}

	/**
	 * Recent GPS paths for active trips (polylines / heatmap).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_fleet_tracks( WP_REST_Request $request ) {
		global $wpdb;
		$hours = (int) $request->get_param( 'hours' );
		if ( $hours < 1 ) {
			$hours = 48;
		}
		$hours = min( 168, $hours );
		$hours = (int) apply_filters( 'bvf_fleet_tracks_hours_cap', $hours );

		$trips   = $wpdb->prefix . 'bvf_trips';
		$vessels = $wpdb->prefix . 'bvf_vessels';
		$logs    = $wpdb->prefix . 'bvf_location_logs';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$trip_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT t.id AS trip_id, v.name AS vessel_name FROM {$trips} t
				INNER JOIN {$vessels} v ON v.id = t.vessel_id
				WHERE t.status = %s",
				'active'
			),
			ARRAY_A
		);

		if ( ! is_array( $trip_rows ) ) {
			return new WP_Error( 'bvf_db_error', __( 'Could not load trips.', 'bosvesfinder' ), array( 'status' => 500 ) );
		}

		$max_pts = (int) apply_filters( 'bvf_fleet_tracks_max_points', 160 );
		$max_pts = max( 20, min( 400, $max_pts ) );

		$out = array();
		foreach ( $trip_rows as $tr ) {
			$tid = (int) $tr['trip_id'];
			$pts = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT latitude, longitude FROM {$logs}
					WHERE trip_id = %d AND created_at >= DATE_SUB(NOW(), INTERVAL %d HOUR)
					ORDER BY id ASC",
					$tid,
					$hours
				),
				ARRAY_A
			);
			if ( empty( $pts ) ) {
				continue;
			}

			$path = array();
			foreach ( $pts as $p ) {
				$path[] = array( round( (float) $p['latitude'], 6 ), round( (float) $p['longitude'], 6 ) );
			}

			$path = $this->decimate_track_points( $path, $max_pts );

			$out[] = array(
				'trip_id'     => $tid,
				'vessel_name' => $tr['vessel_name'],
				'points'      => $path,
			);
		}

		return rest_ensure_response( $out );
	}

	/**
	 * @param array<int,array{0:float,1:float}> $path Lat/lng pairs.
	 * @param int                               $max  Max points.
	 * @return array<int,array{0:float,1:float}>
	 */
	private function decimate_track_points( array $path, $max ) {
		$n = count( $path );
		if ( $n <= $max ) {
			return $path;
		}
		$step = (int) ceil( $n / $max );
		$out  = array();
		for ( $i = 0; $i < $n; $i += $step ) {
			$out[] = $path[ $i ];
		}
		$last = $path[ $n - 1 ];
		if ( empty( $out ) ) {
			return array( $last );
		}
		$tail = end( $out );
		if ( ! is_array( $tail ) || abs( (float) $tail[0] - (float) $last[0] ) > 1e-5 || abs( (float) $tail[1] - (float) $last[1] ) > 1e-5 ) {
			$out[] = $last;
		}
		return $out;
	}

	/**
	 * @return array<int,array<string,mixed>>|WP_Error
	 */
	private function query_fleet_live_payload() {
		global $wpdb;
		$trips   = $wpdb->prefix . 'bvf_trips';
		$vessels = $wpdb->prefix . 'bvf_vessels';
		$logs    = $wpdb->prefix . 'bvf_location_logs';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table names from trusted prefix.
		$rows = $wpdb->get_results(
			"SELECT t.id AS trip_id, t.vessel_id, t.captain_user_id, v.name AS vessel_name,
				l.latitude, l.longitude, l.speed_knots, l.created_at AS last_report_at
			FROM {$trips} t
			INNER JOIN {$vessels} v ON v.id = t.vessel_id
			LEFT JOIN {$logs} l ON l.id = (
				SELECT MAX(lo.id) FROM {$logs} lo WHERE lo.trip_id = t.id
			)
			WHERE t.status = 'active'",
			ARRAY_A
		);

		if ( ! is_array( $rows ) ) {
			return new WP_Error( 'bvf_db_error', __( 'Could not load fleet data.', 'bosvesfinder' ), array( 'status' => 500 ) );
		}

		$out = array();
		foreach ( $rows as $row ) {
			$last  = isset( $row['last_report_at'] ) ? $row['last_report_at'] : null;
			$speed = isset( $row['speed_knots'] ) ? (float) $row['speed_knots'] : null;
			$out[] = array(
				'trip_id'         => (int) $row['trip_id'],
				'vessel_id'       => (int) $row['vessel_id'],
				'vessel_name'     => $row['vessel_name'],
				'captain_user_id' => (int) $row['captain_user_id'],
				'latitude'        => isset( $row['latitude'] ) ? (float) $row['latitude'] : null,
				'longitude'       => isset( $row['longitude'] ) ? (float) $row['longitude'] : null,
				'speed_knots'     => $speed,
				'last_report_at'  => $last ? gmdate( 'c', strtotime( get_gmt_from_date( $last ) ) ) : null,
				'computed_status' => $this->compute_vessel_status( $last, $speed ),
			);
		}

		return $out;
	}

	/**
	 * List vessels (for dashboards; same cap as map for Phase 1).
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function list_vessels() {
		global $wpdb;
		$table = $wpdb->prefix . 'bvf_vessels';
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( "SELECT id, name, external_id, status, assigned_captain_user_id, created_at FROM {$table} ORDER BY name ASC", ARRAY_A );
		if ( ! is_array( $rows ) ) {
			return new WP_Error( 'bvf_db_error', __( 'Could not load vessels.', 'bosvesfinder' ), array( 'status' => 500 ) );
		}
		return rest_ensure_response( $rows );
	}

	/**
	 * Create a vessel.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function create_vessel( WP_REST_Request $request ) {
		global $wpdb;
		$table = $wpdb->prefix . 'bvf_vessels';
		$now   = current_time( 'mysql' );

		$name = sanitize_text_field( $request->get_param( 'name' ) );
		if ( empty( $name ) ) {
			return new WP_Error( 'bvf_invalid', __( 'Vessel name is required.', 'bosvesfinder' ), array( 'status' => 400 ) );
		}

		$status = sanitize_key( $request->get_param( 'status' ) );
		if ( ! in_array( $status, array( 'active', 'inactive', 'maintenance' ), true ) ) {
			$status = 'active';
		}

		$captain_param = $request->get_param( 'assigned_captain_user_id' );
		$captain_id    = ( null !== $captain_param && '' !== $captain_param && (int) $captain_param > 0 )
			? (int) $captain_param
			: null;

		$insert  = array(
			'name'        => $name,
			'external_id' => sanitize_text_field( (string) $request->get_param( 'external_id' ) ),
			'status'      => $status,
			'created_at'  => $now,
			'updated_at'  => $now,
		);
		$formats = array( '%s', '%s', '%s', '%s', '%s' );

		if ( null !== $captain_id ) {
			$insert['assigned_captain_user_id'] = $captain_id;
			$formats[]                          = '%d';
		}

		$ok = $wpdb->insert( $table, $insert, $formats );

		if ( ! $ok ) {
			return new WP_Error( 'bvf_db_error', __( 'Could not create vessel.', 'bosvesfinder' ), array( 'status' => 500 ) );
		}

		return rest_ensure_response(
			array(
				'id' => (int) $wpdb->insert_id,
			)
		);
	}

	/**
	 * Create a trip (typically active) for a vessel and captain.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function create_trip( WP_REST_Request $request ) {
		global $wpdb;
		$vessel_id = (int) $request->get_param( 'vessel_id' );
		$captain_id = (int) $request->get_param( 'captain_user_id' );
		$status     = sanitize_key( $request->get_param( 'status' ) );

		if ( $vessel_id <= 0 || $captain_id <= 0 ) {
			return new WP_Error( 'bvf_invalid', __( 'vessel_id and captain_user_id are required.', 'bosvesfinder' ), array( 'status' => 400 ) );
		}

		if ( ! in_array( $status, array( 'pending', 'active', 'completed', 'cancelled' ), true ) ) {
			$status = 'active';
		}

		$vessels = $wpdb->prefix . 'bvf_vessels';
		$exists  = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$vessels} WHERE id = %d", $vessel_id ) );
		if ( ! $exists ) {
			return new WP_Error( 'bvf_invalid', __( 'Vessel not found.', 'bosvesfinder' ), array( 'status' => 404 ) );
		}

		$now          = current_time( 'mysql' );
		$origin_label = sanitize_text_field( (string) $request->get_param( 'origin_label' ) );
		$dest_label   = sanitize_text_field( (string) $request->get_param( 'destination_label' ) );

		$row     = array(
			'vessel_id'         => $vessel_id,
			'captain_user_id'   => $captain_id,
			'status'            => $status,
			'origin_label'      => $origin_label,
			'destination_label' => $dest_label,
		);
		$formats = array( '%d', '%d', '%s', '%s', '%s' );

		if ( 'active' === $status ) {
			$row['started_at'] = $now;
			$formats[]        = '%s';
		}

		$row['created_at'] = $now;
		$row['updated_at'] = $now;
		$formats[]         = '%s';
		$formats[]         = '%s';

		$trips = $wpdb->prefix . 'bvf_trips';
		$ok    = $wpdb->insert( $trips, $row, $formats );

		if ( ! $ok ) {
			return new WP_Error( 'bvf_db_error', __( 'Could not create trip.', 'bosvesfinder' ), array( 'status' => 500 ) );
		}

		if ( 'active' === $status ) {
			BVF_Fleet_Cache::bust();
		}

		return rest_ensure_response(
			array(
				'id' => (int) $wpdb->insert_id,
			)
		);
	}

	/**
	 * Current user’s active trip (at most one).
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_my_active_trip() {
		global $wpdb;
		$uid   = get_current_user_id();
		$trips = $wpdb->prefix . 'bvf_trips';
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, vessel_id, captain_user_id, status, origin_label, destination_label, started_at
				FROM {$trips} WHERE captain_user_id = %d AND status = %s ORDER BY id DESC LIMIT 1",
				$uid,
				'active'
			),
			ARRAY_A
		);

		if ( ! $row ) {
			return rest_ensure_response( null );
		}

		return rest_ensure_response( $row );
	}

	/**
	 * Paginated trips for integrations and dashboards.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function list_trips_rest( WP_REST_Request $request ) {
		global $wpdb;
		$page     = max( 1, (int) $request->get_param( 'page' ) );
		$per_page = min( 100, max( 1, (int) $request->get_param( 'per_page' ) ) );
		$status   = sanitize_key( (string) $request->get_param( 'status' ) );
		$offset   = ( $page - 1 ) * $per_page;

		$trips   = $wpdb->prefix . 'bvf_trips';
		$vessels = $wpdb->prefix . 'bvf_vessels';

		if ( $status && in_array( $status, array( 'pending', 'active', 'completed', 'cancelled' ), true ) ) {
			$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$trips} WHERE status = %s", $status ) );
			$rows  = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT t.*, v.name AS vessel_name FROM {$trips} t
					INNER JOIN {$vessels} v ON v.id = t.vessel_id
					WHERE t.status = %s
					ORDER BY t.id DESC
					LIMIT %d OFFSET %d",
					$status,
					$per_page,
					$offset
				),
				ARRAY_A
			);
		} else {
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$trips}" );
			$rows  = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT t.*, v.name AS vessel_name FROM {$trips} t
					INNER JOIN {$vessels} v ON v.id = t.vessel_id
					ORDER BY t.id DESC
					LIMIT %d OFFSET %d",
					$per_page,
					$offset
				),
				ARRAY_A
			);
		}

		if ( ! is_array( $rows ) ) {
			return new WP_Error( 'bvf_db_error', __( 'Could not load trips.', 'bosvesfinder' ), array( 'status' => 500 ) );
		}

		$response  = rest_ensure_response( $rows );
		$max_pages = max( 1, (int) ceil( $total / $per_page ) );
		$response->header( 'X-WP-Total', (string) $total );
		$response->header( 'X-WP-TotalPages', (string) $max_pages );
		return $response;
	}

	/**
	 * Single trip with vessel name.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_trip_rest( WP_REST_Request $request ) {
		global $wpdb;
		$id      = (int) $request['id'];
		$trips   = $wpdb->prefix . 'bvf_trips';
		$vessels = $wpdb->prefix . 'bvf_vessels';
		$row     = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT t.*, v.name AS vessel_name FROM {$trips} t
				INNER JOIN {$vessels} v ON v.id = t.vessel_id
				WHERE t.id = %d",
				$id
			),
			ARRAY_A
		);
		if ( ! $row ) {
			return new WP_Error( 'bvf_not_found', __( 'Trip not found.', 'bosvesfinder' ), array( 'status' => 404 ) );
		}
		return rest_ensure_response( $row );
	}

	/**
	 * Append a GPS fix to an active trip.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function post_trip_position( WP_REST_Request $request ) {
		$uid = get_current_user_id();
		$rl  = BVF_Rate_Limit::allow_or_error(
			'position',
			$uid,
			(int) apply_filters( 'bvf_rate_limit_position_max', 300 ),
			(int) apply_filters( 'bvf_rate_limit_position_window', 60 )
		);
		if ( is_wp_error( $rl ) ) {
			return $rl;
		}

		global $wpdb;
		$trip_id = (int) $request['id'];
		$trips   = $wpdb->prefix . 'bvf_trips';

		$trip = $wpdb->get_row( $wpdb->prepare( "SELECT id, status, vessel_id FROM {$trips} WHERE id = %d", $trip_id ), ARRAY_A );
		if ( ! $trip ) {
			return new WP_Error( 'bvf_not_found', __( 'Trip not found.', 'bosvesfinder' ), array( 'status' => 404 ) );
		}
		if ( 'active' !== $trip['status'] ) {
			return new WP_Error( 'bvf_invalid', __( 'Trip is not active.', 'bosvesfinder' ), array( 'status' => 400 ) );
		}

		$lat = (float) $request->get_param( 'latitude' );
		$lng = (float) $request->get_param( 'longitude' );
		if ( $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180 ) {
			return new WP_Error( 'bvf_invalid', __( 'Invalid coordinates.', 'bosvesfinder' ), array( 'status' => 400 ) );
		}

		$logs = $wpdb->prefix . 'bvf_location_logs';
		$now  = current_time( 'mysql' );
		$data = array(
			'trip_id'         => $trip_id,
			'user_id'         => get_current_user_id(),
			'latitude'        => round( $lat, 7 ),
			'longitude'       => round( $lng, 7 ),
			'accuracy_m'      => $this->nullable_float( $request->get_param( 'accuracy_m' ) ),
			'speed_knots'     => $this->nullable_float( $request->get_param( 'speed_knots' ) ),
			'heading_degrees' => $this->nullable_float( $request->get_param( 'heading_degrees' ) ),
			'altitude_m'      => $this->nullable_float( $request->get_param( 'altitude_m' ) ),
			'battery_percent' => $this->nullable_int( $request->get_param( 'battery_percent' ) ),
			'source'          => sanitize_key( $request->get_param( 'source' ) ) ?: 'mobile',
			'created_at'      => $now,
		);

		$ok = $wpdb->insert(
			$logs,
			$data,
			array( '%d', '%d', '%f', '%f', '%f', '%f', '%f', '%f', '%d', '%s', '%s' )
		);

		if ( ! $ok ) {
			return new WP_Error( 'bvf_db_error', __( 'Could not save position.', 'bosvesfinder' ), array( 'status' => 500 ) );
		}

		BVF_Fleet_Cache::bust();

		BVF_Geofence::evaluate_position(
			$trip_id,
			(int) $trip['vessel_id'],
			get_current_user_id(),
			$lat,
			$lng
		);

		$this->maybe_battery_low_alert(
			$trip_id,
			(int) $trip['vessel_id'],
			$uid,
			$data['battery_percent']
		);

		return rest_ensure_response(
			array(
				'id' => (int) $wpdb->insert_id,
			)
		);
	}

	/**
	 * Mark trip completed.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function complete_trip( WP_REST_Request $request ) {
		global $wpdb;
		$trip_id = (int) $request['id'];
		$trips   = $wpdb->prefix . 'bvf_trips';
		$now     = current_time( 'mysql' );

		$updated = $wpdb->update(
			$trips,
			array(
				'status'   => 'completed',
				'ended_at' => $now,
				'updated_at' => $now,
			),
			array( 'id' => $trip_id ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			return new WP_Error( 'bvf_db_error', __( 'Could not update trip.', 'bosvesfinder' ), array( 'status' => 500 ) );
		}

		if ( 0 === $updated ) {
			return new WP_Error( 'bvf_not_found', __( 'Trip not found.', 'bosvesfinder' ), array( 'status' => 404 ) );
		}

		BVF_Fleet_Cache::bust();

		return rest_ensure_response( array( 'ok' => true ) );
	}

	/**
	 * @param string|null $last_mysql Last log time in site timezone.
	 * @param float|null  $speed_knots Speed.
	 * @return string moving|idle|offline
	 */
	private function compute_vessel_status( $last_mysql, $speed_knots ) {
		if ( empty( $last_mysql ) ) {
			return 'offline';
		}
		$ts = strtotime( get_gmt_from_date( $last_mysql ) );
		if ( false === $ts || ( time() - $ts ) > self::OFFLINE_AFTER_SECONDS ) {
			return 'offline';
		}
		if ( null !== $speed_knots && $speed_knots > self::MOVING_SPEED_KNOTS ) {
			return 'moving';
		}
		return 'idle';
	}

	/**
	 * @param int $trip_id Trip ID.
	 */
	private function user_is_trip_captain( $trip_id ) {
		global $wpdb;
		$trips  = $wpdb->prefix . 'bvf_trips';
		$captain = $wpdb->get_var( $wpdb->prepare( "SELECT captain_user_id FROM {$trips} WHERE id = %d", $trip_id ) );
		return (int) $captain === (int) get_current_user_id();
	}

	/**
	 * @param mixed $value Raw value.
	 * @return float|null
	 */
	private function nullable_float( $value ) {
		if ( null === $value || '' === $value ) {
			return null;
		}
		return is_numeric( $value ) ? (float) $value : null;
	}

	/**
	 * @param mixed $value Raw value.
	 * @return int|null
	 */
	private function nullable_int( $value ) {
		if ( null === $value || '' === $value ) {
			return null;
		}
		return is_numeric( $value ) ? (int) $value : null;
	}

	/**
	 * Record low-battery warning (deduped per trip per hour).
	 *
	 * @param int      $trip_id         Trip ID.
	 * @param int      $vessel_id       Vessel ID.
	 * @param int      $user_id         Reporting user.
	 * @param int|null $battery_percent Battery level 0–100.
	 */
	private function maybe_battery_low_alert( $trip_id, $vessel_id, $user_id, $battery_percent ) {
		if ( null === $battery_percent || $battery_percent > 15 ) {
			return;
		}
		if ( $battery_percent < 0 || $battery_percent > 100 ) {
			return;
		}

		global $wpdb;
		$al    = $wpdb->prefix . 'bvf_alerts';
		$since = gmdate( 'Y-m-d H:i:s', time() - 3600 );
		$dup   = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$al} WHERE trip_id = %d AND alert_type = %s AND created_at >= %s",
				$trip_id,
				'battery_low',
				$since
			)
		);
		if ( $dup > 0 ) {
			return;
		}

		$now = current_time( 'mysql' );
		$wpdb->insert(
			$al,
			array(
				'alert_type' => 'battery_low',
				'severity'   => 'warning',
				'trip_id'    => $trip_id,
				'vessel_id'  => $vessel_id,
				'user_id'    => $user_id,
				'payload'    => wp_json_encode( array( 'battery_percent' => (int) $battery_percent ) ),
				'created_at' => $now,
			),
			array( '%s', '%s', '%d', '%d', '%d', '%s', '%s' )
		);

		$alert_id = (int) $wpdb->insert_id;
		do_action( 'bvf_alert_created', $alert_id, 'battery_low', $trip_id, $vessel_id );
	}

	/**
	 * Query args for GET /trips.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	private function list_trips_args() {
		return array(
			'page'     => array(
				'type'    => 'integer',
				'default' => 1,
				'minimum' => 1,
			),
			'per_page' => array(
				'type'    => 'integer',
				'default' => 20,
				'minimum' => 1,
				'maximum' => 100,
			),
			'status'   => array(
				'type' => 'string',
			),
		);
	}

	/**
	 * Args for vessel POST.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	private function vessel_create_args() {
		return array(
			'name'                     => array(
				'required'          => true,
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'external_id'              => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'status'                   => array(
				'type'    => 'string',
				'default' => 'active',
			),
			'assigned_captain_user_id' => array(
				'type' => 'integer',
			),
		);
	}

	/**
	 * Args for trip POST.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	private function trip_create_args() {
		return array(
			'vessel_id'           => array(
				'required' => true,
				'type'     => 'integer',
			),
			'captain_user_id'     => array(
				'required' => true,
				'type'     => 'integer',
			),
			'status'              => array(
				'type'    => 'string',
				'default' => 'active',
			),
			'origin_label'        => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'destination_label' => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
		);
	}

	/**
	 * Args for position POST.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	private function position_args() {
		return array(
			'latitude'        => array(
				'required' => true,
				'type'     => 'number',
			),
			'longitude'       => array(
				'required' => true,
				'type'     => 'number',
			),
			'accuracy_m'      => array( 'type' => 'number' ),
			'speed_knots'     => array( 'type' => 'number' ),
			'heading_degrees' => array( 'type' => 'number' ),
			'altitude_m'      => array( 'type' => 'number' ),
			'battery_percent' => array( 'type' => 'integer' ),
			'source'          => array(
				'type'    => 'string',
				'default' => 'mobile',
			),
		);
	}
}
