<?php
/**
 * Email notifications for SOS and optional alert types.
 *
 * @package BosVesFinder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sends wp_mail to operations addresses from settings.
 */
class BVF_Notifications {

	/**
	 * Parse option into array of valid emails.
	 *
	 * @return string[]
	 */
	public static function get_ops_emails() {
		$raw = (string) get_option( 'bvf_ops_notification_emails', '' );
		if ( '' === trim( $raw ) ) {
			$admin = get_bloginfo( 'admin_email' );
			return $admin ? array( $admin ) : array();
		}
		$parts = preg_split( '/[\s,;]+/', $raw, -1, PREG_SPLIT_NO_EMPTY );
		$out   = array();
		foreach ( $parts as $p ) {
			$e = sanitize_email( $p );
			if ( is_email( $e ) ) {
				$out[] = $e;
			}
		}
		return array_unique( $out );
	}

	/**
	 * SOS recorded — always email if recipients exist.
	 *
	 * @param int $alert_id  Alert row ID.
	 * @param int $trip_id   Trip ID.
	 * @param int $vessel_id Vessel ID.
	 */
	public static function notify_sos( $alert_id, $trip_id, $vessel_id ) {
		$to = self::get_ops_emails();
		if ( empty( $to ) ) {
			return;
		}

		global $wpdb;
		$vessels = $wpdb->prefix . 'bvf_vessels';
		$name    = $wpdb->get_var( $wpdb->prepare( "SELECT name FROM {$vessels} WHERE id = %d", $vessel_id ) );

		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		/* translators: 1: site name */
		$subject = sprintf( __( '[%1$s] BOSVesFinder — SOS emergency', 'bosvesfinder' ), $site );

		$lines = array(
			__( 'An SOS alert was triggered from the captain app.', 'bosvesfinder' ),
			'',
			__( 'Alert ID:', 'bosvesfinder' ) . ' ' . $alert_id,
			__( 'Trip ID:', 'bosvesfinder' ) . ' ' . $trip_id,
			__( 'Vessel:', 'bosvesfinder' ) . ' ' . ( $name ? $name : '#' . $vessel_id ),
			__( 'Time (site):', 'bosvesfinder' ) . ' ' . current_time( 'mysql' ),
			'',
			admin_url( 'admin.php?page=bosvesfinder' ),
		);

		$body = implode( "\n", $lines );
		$headers = array( 'Content-Type: text/plain; charset=UTF-8' );

		foreach ( $to as $email ) {
			wp_mail( $email, $subject, $body, $headers );
		}
	}

	/**
	 * Geofence or generic operational alert email.
	 *
	 * @param int    $alert_id  Alert ID.
	 * @param string $headline  Short title.
	 * @param int    $trip_id   Trip ID.
	 * @param int    $vessel_id Vessel ID.
	 */
	public static function notify_generic_alert( $alert_id, $headline, $trip_id, $vessel_id ) {
		$to = self::get_ops_emails();
		if ( empty( $to ) ) {
			return;
		}

		global $wpdb;
		$vessels = $wpdb->prefix . 'bvf_vessels';
		$name    = $wpdb->get_var( $wpdb->prepare( "SELECT name FROM {$vessels} WHERE id = %d", $vessel_id ) );

		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		/* translators: 1: site name */
		$subject = sprintf( __( '[%1$s] BOSVesFinder — %2$s', 'bosvesfinder' ), $site, $headline );

		$lines = array(
			$headline,
			'',
			__( 'Alert ID:', 'bosvesfinder' ) . ' ' . $alert_id,
			__( 'Trip ID:', 'bosvesfinder' ) . ' ' . $trip_id,
			__( 'Vessel:', 'bosvesfinder' ) . ' ' . ( $name ? $name : '#' . $vessel_id ),
			'',
			admin_url( 'admin.php?page=bosvesfinder' ),
		);

		$body    = implode( "\n", $lines );
		$headers = array( 'Content-Type: text/plain; charset=UTF-8' );

		foreach ( $to as $email ) {
			wp_mail( $email, $subject, $body, $headers );
		}
	}
}
