<?php
/**
 * Circular geofence checks against GPS positions.
 *
 * @package BosVesFinder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Evaluates active geofences when a position is recorded.
 */
class BVF_Geofence {

	/**
	 * Dedupe identical zone violations per trip (seconds).
	 *
	 * @var int
	 */
	private const DEDUPE_SECONDS = 900;

	/**
	 * Haversine distance in meters between two WGS84 points.
	 *
	 * @param float $lat1 Latitude 1.
	 * @param float $lng1 Longitude 1.
	 * @param float $lat2 Latitude 2.
	 * @param float $lng2 Longitude 2.
	 */
	public static function distance_meters( $lat1, $lng1, $lat2, $lng2 ) {
		$earth = 6371000.0;
		$phi1  = deg2rad( $lat1 );
		$phi2  = deg2rad( $lat2 );
		$dphi  = deg2rad( $lat2 - $lat1 );
		$dl    = deg2rad( $lng2 - $lng1 );

		$a = sin( $dphi / 2 ) * sin( $dphi / 2 ) + cos( $phi1 ) * cos( $phi2 ) * sin( $dl / 2 ) * sin( $dl / 2 );
		$c = 2 * atan2( sqrt( $a ), sqrt( 1 - $a ) );

		return $earth * $c;
	}

	/**
	 * Check position against all active circular geofences; insert alerts on violation.
	 *
	 * @param int   $trip_id   Trip ID.
	 * @param int   $vessel_id Vessel ID.
	 * @param int   $user_id   Reporting user.
	 * @param float $lat       Latitude.
	 * @param float $lng       Longitude.
	 */
	public static function evaluate_position( $trip_id, $vessel_id, $user_id, $lat, $lng ) {
		global $wpdb;
		$gf = $wpdb->prefix . 'bvf_geofences';
		$al = $wpdb->prefix . 'bvf_alerts';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$zones = $wpdb->get_results(
			"SELECT id, name, zone_type, center_lat, center_lng, radius_meters FROM {$gf}
			WHERE active = 1 AND center_lat IS NOT NULL AND center_lng IS NOT NULL
				AND radius_meters IS NOT NULL AND radius_meters > 0",
			ARRAY_A
		);

		if ( empty( $zones ) ) {
			return;
		}

		$now_mysql = current_time( 'mysql' );

		foreach ( $zones as $z ) {
			$gid   = (int) $z['id'];
			$clat  = (float) $z['center_lat'];
			$clng  = (float) $z['center_lng'];
			$rad   = (int) $z['radius_meters'];
			$type  = sanitize_key( $z['zone_type'] );
			$dist  = self::distance_meters( $lat, $lng, $clat, $clng );

			$violate = false;
			$reason  = '';
			if ( 'restricted' === $type && $dist <= $rad ) {
				$violate = true;
				$reason  = 'inside_restricted_zone';
			} elseif ( 'operational' === $type && $dist > $rad ) {
				$violate = true;
				$reason  = 'outside_operational_zone';
			}

			if ( ! $violate ) {
				continue;
			}

			if ( self::has_recent_geofence_alert( $trip_id, $gid ) ) {
				continue;
			}

			$payload = wp_json_encode(
				array(
					'geofence_id'   => $gid,
					'geofence_name' => $z['name'],
					'zone_type'     => $type,
					'distance_m'    => round( $dist, 1 ),
					'radius_m'      => $rad,
					'reason'        => $reason,
					'latitude'      => $lat,
					'longitude'     => $lng,
				)
			);

			$wpdb->insert(
				$al,
				array(
					'alert_type' => 'geofence_violation',
					'severity'   => 'restricted' === $type ? 'high' : 'warning',
					'trip_id'    => $trip_id,
					'vessel_id'  => $vessel_id,
					'user_id'    => $user_id,
					'payload'    => $payload,
					'created_at' => $now_mysql,
				),
				array( '%s', '%s', '%d', '%d', '%d', '%s', '%s' )
			);

			$alert_id = (int) $wpdb->insert_id;
			do_action( 'bvf_alert_created', $alert_id, 'geofence_violation', $trip_id, $vessel_id );

			if ( get_option( 'bvf_email_geofence' ) === '1' ) {
				BVF_Notifications::notify_generic_alert(
					$alert_id,
					sprintf(
						/* translators: %s: geofence name */
						__( 'Geofence: %s', 'bosvesfinder' ),
						$z['name']
					),
					$trip_id,
					$vessel_id
				);
			}
		}
	}

	/**
	 * @param int $trip_id Trip ID.
	 * @param int $gf_id   Geofence ID.
	 */
	private static function has_recent_geofence_alert( $trip_id, $gf_id ) {
		global $wpdb;
		$al    = $wpdb->prefix . 'bvf_alerts';
		$since = gmdate( 'Y-m-d H:i:s', time() - self::DEDUPE_SECONDS );
		$like  = '%"geofence_id":' . (int) $gf_id . '%';

		$c = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$al} WHERE trip_id = %d AND alert_type = %s AND created_at >= %s AND payload LIKE %s",
				$trip_id,
				'geofence_violation',
				$since,
				$like
			)
		);

		return (int) $c > 0;
	}

	/**
	 * Approximate track length in nautical miles for a trip (sum of leg haversine in NM).
	 *
	 * @param int $trip_id Trip ID.
	 */
	public static function trip_distance_nm( $trip_id ) {
		global $wpdb;
		$logs = $wpdb->prefix . 'bvf_location_logs';
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT latitude, longitude FROM {$logs} WHERE trip_id = %d ORDER BY id ASC",
				$trip_id
			),
			ARRAY_A
		);
		if ( empty( $rows ) || count( $rows ) < 2 ) {
			return 0.0;
		}

		$total_m = 0.0;
		$prev    = null;
		foreach ( $rows as $r ) {
			$la = (float) $r['latitude'];
			$lo = (float) $r['longitude'];
			if ( null !== $prev ) {
				$total_m += self::distance_meters( $prev['lat'], $prev['lng'], $la, $lo );
			}
			$prev = array( 'lat' => $la, 'lng' => $lo );
		}

		return round( $total_m / 1852.0, 2 );
	}
}
