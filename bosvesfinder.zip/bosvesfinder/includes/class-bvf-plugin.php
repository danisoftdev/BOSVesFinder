<?php
/**
 * Core plugin loader.
 *
 * @package BosVesFinder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers hooks and loads subsystems.
 */
class BVF_Plugin {

	/**
	 * REST controller instance.
	 *
	 * @var BVF_REST
	 */
	private $rest;

	/**
	 * Admin screens.
	 *
	 * @var BVF_Admin
	 */
	private $admin;

	/**
	 * Start WordPress integrations.
	 */
	public function run() {
		$this->rest  = new BVF_REST();
		$this->admin = new BVF_Admin();
		$this->admin->init();

		BVF_Cron::init();

		add_action( 'init', array( $this, 'load_textdomain' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_public_assets' ) );
		add_shortcode( 'bvf_fleet_map', array( $this, 'shortcode_fleet_map' ) );
		add_shortcode( 'bvf_captain_tracker', array( $this, 'shortcode_captain_tracker' ) );

		$this->rest->register_hooks();
	}

	/**
	 * Load translations (for future strings).
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'bosvesfinder', false, dirname( BVF_PLUGIN_BASENAME ) . '/languages' );
	}

	/**
	 * Register scripts/styles (enqueued only when shortcode runs).
	 */
	public function register_public_assets() {
		wp_register_style(
			'bvf-leaflet',
			'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
			array(),
			'1.9.4'
		);
		wp_register_script(
			'bvf-leaflet',
			'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
			array(),
			'1.9.4',
			true
		);
		wp_register_script(
			'bvf-leaflet-heat',
			'https://unpkg.com/leaflet.heat@0.2.0/dist/leaflet-heat.js',
			array( 'bvf-leaflet' ),
			'0.2.0',
			true
		);
		wp_register_style(
			'bvf-fleet-map',
			BVF_PLUGIN_URL . 'public/css/fleet-map.css',
			array( 'bvf-leaflet' ),
			BVF_VERSION
		);
		wp_register_script(
			'bvf-fleet-map',
			BVF_PLUGIN_URL . 'public/js/fleet-map.js',
			array( 'bvf-leaflet', 'bvf-leaflet-heat' ),
			BVF_VERSION,
			true
		);
		wp_register_style(
			'bvf-captain-tracker',
			BVF_PLUGIN_URL . 'public/css/captain-tracker.css',
			array(),
			BVF_VERSION
		);
		wp_register_script(
			'bvf-captain-tracker',
			BVF_PLUGIN_URL . 'public/js/captain-tracker.js',
			array(),
			BVF_VERSION,
			true
		);
	}

	/**
	 * Shortcode: interactive fleet map (Leaflet).
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function shortcode_fleet_map( $atts ) {
		if ( ! is_user_logged_in() || ! current_user_can( 'bvf_view_fleet' ) ) {
			return '<p class="bvf-fleet-map__denied">' . esc_html__( 'You must be logged in with fleet map access to view this map.', 'bosvesfinder' ) . '</p>';
		}

		wp_enqueue_style( 'bvf-fleet-map' );
		wp_enqueue_script( 'bvf-fleet-map' );

		$atts = shortcode_atts(
			array(
				'height'      => '420px',
				'tracks'      => '0',
				'heatmap'     => '0',
				'track_hours' => '48',
				'poll'        => '15000',
			),
			$atts,
			'bvf_fleet_map'
		);

		$truthy = function ( $v ) {
			$v = strtolower( (string) $v );
			return in_array( $v, array( '1', 'true', 'yes', 'on' ), true );
		};

		$heatmap = $truthy( $atts['heatmap'] );
		$tracks  = $heatmap || $truthy( $atts['tracks'] );
		$hours   = max( 1, min( 168, absint( $atts['track_hours'] ) ) );
		$poll_ms = max( 5000, min( 120000, absint( $atts['poll'] ) ) );

		$tracks_url = '';
		if ( $tracks ) {
			$tracks_url = add_query_arg(
				'hours',
				$hours,
				rest_url( 'bosvesfinder/v1/fleet/tracks' )
			);
		}

		wp_localize_script(
			'bvf-fleet-map',
			'bvfFleetMap',
			array(
				'restUrl'    => rest_url( 'bosvesfinder/v1/fleet/live' ),
				'tracksUrl'  => $tracks_url,
				'heatmap'    => $heatmap,
				'nonce'      => wp_create_nonce( 'wp_rest' ),
				'pollMs'     => $poll_ms,
				'i18n'       => array(
					'loading' => __( 'Loading fleet…', 'bosvesfinder' ),
					'error'   => __( 'Could not load fleet data.', 'bosvesfinder' ),
				),
			)
		);

		$height = sanitize_text_field( $atts['height'] );
		$uid    = 'bvf-fleet-map-' . wp_unique_id();

		return sprintf(
			'<div class="bvf-fleet-map-wrap bvf-fleet-map-wrap--loading" style="height:%1$s">' .
			'<div class="bvf-fleet-map__loading" aria-live="polite" role="status">%4$s</div>' .
			'<div id="%2$s" class="bvf-fleet-map" role="region" aria-label="%3$s"></div></div>',
			esc_attr( $height ),
			esc_attr( $uid ),
			esc_attr__( 'Fleet map', 'bosvesfinder' ),
			esc_html__( 'Loading map…', 'bosvesfinder' )
		);
	}

	/**
	 * Shortcode: captain tracking panel (GPS + SOS).
	 *
	 * @return string
	 */
	public function shortcode_captain_tracker() {
		if ( ! is_user_logged_in() || ! current_user_can( BVF_Roles::CAP_SUBMIT_TRACKING ) ) {
			return '<p class="bvf-captain__denied">' . esc_html__( 'You must be logged in as a captain (or higher) to use the tracker.', 'bosvesfinder' ) . '</p>';
		}

		wp_enqueue_style( 'bvf-captain-tracker' );
		wp_enqueue_script( 'bvf-captain-tracker' );

		wp_localize_script(
			'bvf-captain-tracker',
			'bvfCaptain',
			array(
				'restBase'   => trailingslashit( rest_url( 'bosvesfinder/v1/' ) ),
				'nonce'      => wp_create_nonce( 'wp_rest' ),
				'intervalMs' => 30000,
				'i18n'       => array(
					'loading'    => __( 'Loading your trip…', 'bosvesfinder' ),
					'noTrip'     => __( 'No active trip. Ask operations to start one for you.', 'bosvesfinder' ),
					'tripLabel'  => __( 'Active trip', 'bosvesfinder' ),
					'sosConfirm' => __( 'Send SOS alert to operations?', 'bosvesfinder' ),
					'sosSent'    => __( 'SOS recorded. Operations have been notified in the system.', 'bosvesfinder' ),
				),
			)
		);

		ob_start();
		?>
		<div class="bvf-captain">
			<h2 class="bvf-captain__title"><?php esc_html_e( 'Captain tracker', 'bosvesfinder' ); ?></h2>
			<p class="bvf-captain__status" aria-live="polite"></p>
			<div class="bvf-captain__actions">
				<button type="button" class="bvf-captain__start" disabled><?php esc_html_e( 'Start tracking', 'bosvesfinder' ); ?></button>
				<button type="button" class="bvf-captain__stop" disabled><?php esc_html_e( 'Stop tracking', 'bosvesfinder' ); ?></button>
				<button type="button" class="bvf-captain__sos" disabled><?php esc_html_e( 'SOS emergency', 'bosvesfinder' ); ?></button>
			</div>
			<p class="bvf-captain__msg" aria-live="polite"></p>
		</div>
		<?php
		return (string) ob_get_clean();
	}
}
