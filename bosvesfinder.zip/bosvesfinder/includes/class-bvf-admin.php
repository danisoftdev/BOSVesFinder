<?php
/**
 * WordPress admin: dashboard, vessels, trips, crew, fuel.
 *
 * @package BosVesFinder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers admin menus, handles POST actions, renders screens.
 */
class BVF_Admin {

	/**
	 * Slugs for admin_enqueue_scripts guard.
	 *
	 * @var string[]
	 */
	private static $page_slugs = array(
		'bosvesfinder',
		'bvf-vessels',
		'bvf-trips',
		'bvf-crew',
		'bvf-fuel',
		'bvf-geofences',
		'bvf-reports',
		'bvf-status',
		'bvf-settings',
	);

	/**
	 * Register hooks.
	 */
	public function init() {
		add_action( 'admin_menu', array( $this, 'register_menus' ) );
		add_action( 'admin_init', array( $this, 'maybe_export_csv' ), 1 );
		add_action( 'admin_init', array( $this, 'maybe_delete_geofence' ), 2 );
		add_action( 'admin_init', array( $this, 'handle_post' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Prefixed table name.
	 *
	 * @param string $suffix Table suffix without bvf_ prefix.
	 */
	private function t( $suffix ) {
		global $wpdb;
		return $wpdb->prefix . 'bvf_' . $suffix;
	}

	/**
	 * Users who may submit tracking (captain dropdown).
	 *
	 * @return WP_User[]
	 */
	private function get_captain_choices() {
		$users = get_users(
			array(
				'orderby'    => 'display_name',
				'capability' => BVF_Roles::CAP_SUBMIT_TRACKING,
			)
		);
		if ( ! empty( $users ) ) {
			return $users;
		}
		return get_users(
			array(
				'orderby' => 'display_name',
				'role__in' => array( 'administrator' ),
			)
		);
	}

	/**
	 * @param int $user_id User ID.
	 */
	private function user_display_name( $user_id ) {
		$user = get_userdata( (int) $user_id );
		return $user ? $user->display_name : '#' . (int) $user_id;
	}

	/**
	 * Admin menu and submenus.
	 */
	public function register_menus() {
		$cap_view = BVF_Roles::CAP_VIEW_FLEET;

		add_menu_page(
			__( 'BOSVesFinder', 'bosvesfinder' ),
			__( 'BOSVesFinder', 'bosvesfinder' ),
			$cap_view,
			'bosvesfinder',
			array( $this, 'render_dashboard' ),
			'dashicons-location-alt',
			58
		);

		add_submenu_page(
			'bosvesfinder',
			__( 'Dashboard', 'bosvesfinder' ),
			__( 'Dashboard', 'bosvesfinder' ),
			$cap_view,
			'bosvesfinder',
			array( $this, 'render_dashboard' )
		);

		add_submenu_page(
			'bosvesfinder',
			__( 'Vessels', 'bosvesfinder' ),
			__( 'Vessels', 'bosvesfinder' ),
			$cap_view,
			'bvf-vessels',
			array( $this, 'render_vessels' )
		);

		add_submenu_page(
			'bosvesfinder',
			__( 'Trips', 'bosvesfinder' ),
			__( 'Trips', 'bosvesfinder' ),
			$cap_view,
			'bvf-trips',
			array( $this, 'render_trips' )
		);

		add_submenu_page(
			'bosvesfinder',
			__( 'Fuel', 'bosvesfinder' ),
			__( 'Fuel', 'bosvesfinder' ),
			$cap_view,
			'bvf-fuel',
			array( $this, 'render_fuel' )
		);

		add_submenu_page(
			'bosvesfinder',
			__( 'Crew', 'bosvesfinder' ),
			__( 'Crew', 'bosvesfinder' ),
			$cap_view,
			'bvf-crew',
			array( $this, 'render_crew' )
		);

		add_submenu_page(
			'bosvesfinder',
			__( 'Geofences', 'bosvesfinder' ),
			__( 'Geofences', 'bosvesfinder' ),
			$cap_view,
			'bvf-geofences',
			array( $this, 'render_geofences' )
		);

		add_submenu_page(
			'bosvesfinder',
			__( 'Reports', 'bosvesfinder' ),
			__( 'Reports', 'bosvesfinder' ),
			$cap_view,
			'bvf-reports',
			array( $this, 'render_reports' )
		);

		add_submenu_page(
			'bosvesfinder',
			__( 'System status', 'bosvesfinder' ),
			__( 'Status', 'bosvesfinder' ),
			$cap_view,
			'bvf-status',
			array( $this, 'render_status' )
		);

		add_submenu_page(
			'bosvesfinder',
			__( 'BVF Settings', 'bosvesfinder' ),
			__( 'Settings', 'bosvesfinder' ),
			BVF_Roles::CAP_MANAGE_FLEET,
			'bvf-settings',
			array( $this, 'render_settings' )
		);
	}

	/**
	 * Enqueue admin styles on BVF pages.
	 *
	 * @param string $hook_suffix Current admin page.
	 */
	public function enqueue_assets( $hook_suffix ) {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		if ( ! in_array( $page, self::$page_slugs, true ) ) {
			return;
		}
		wp_enqueue_style(
			'bvf-admin',
			BVF_PLUGIN_URL . 'admin/css/bvf-admin.css',
			array(),
			BVF_VERSION
		);
	}

	/**
	 * Handle form posts (PRG).
	 */
	public function handle_post() {
		if ( ! isset( $_POST['bvf_admin_action'] ) || ! isset( $_POST['_bvf_admin_nonce'] ) ) {
			return;
		}

		if ( ! current_user_can( BVF_Roles::CAP_MANAGE_FLEET ) ) {
			return;
		}

		$action = sanitize_key( wp_unslash( $_POST['bvf_admin_action'] ) );
		check_admin_referer( 'bvf_admin_' . $action, '_bvf_admin_nonce' );

		global $wpdb;

		switch ( $action ) {
			case 'save_vessel':
				$this->post_save_vessel();
				break;
			case 'save_trip':
				$this->post_save_trip();
				break;
			case 'complete_trip':
				$this->post_complete_trip();
				break;
			case 'save_crew':
				$this->post_save_crew();
				break;
			case 'save_fuel':
				$this->post_save_fuel();
				break;
			case 'ack_alert':
				$this->post_ack_alert();
				break;
			case 'save_geofence':
				$this->post_save_geofence();
				break;
			case 'save_settings':
				$this->post_save_settings();
				break;
			default:
				break;
		}
	}

	/**
	 * Redirect after successful POST.
	 *
	 * @param string               $page   Menu slug.
	 * @param array<string,string> $extra  Query args.
	 */
	private function redirect_with_message( $page, $extra = array() ) {
		$args = array_merge(
			array(
				'page'    => $page,
				'bvf_msg' => 'saved',
			),
			$extra
		);
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Insert or update vessel.
	 */
	private function post_save_vessel() {
		global $wpdb;
		$table = $this->t( 'vessels' );
		$now   = current_time( 'mysql' );

		$id   = isset( $_POST['vessel_id'] ) ? absint( $_POST['vessel_id'] ) : 0;
		$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		if ( '' === $name ) {
			return;
		}

		$status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'active';
		if ( ! in_array( $status, array( 'active', 'inactive', 'maintenance' ), true ) ) {
			$status = 'active';
		}

		$external = isset( $_POST['external_id'] ) ? sanitize_text_field( wp_unslash( $_POST['external_id'] ) ) : '';
		$captain  = isset( $_POST['assigned_captain_user_id'] ) ? absint( $_POST['assigned_captain_user_id'] ) : 0;

		if ( $id > 0 ) {
			$data    = array(
				'name'        => $name,
				'external_id' => $external,
				'status'      => $status,
				'updated_at'  => $now,
			);
			$formats = array( '%s', '%s', '%s', '%s' );
			if ( $captain > 0 ) {
				$data['assigned_captain_user_id'] = $captain;
				$formats[]                        = '%d';
			} else {
				$data['assigned_captain_user_id'] = null;
				$formats[]                         = '%d';
			}
			$wpdb->update( $table, $data, array( 'id' => $id ), $formats, array( '%d' ) );
			$this->redirect_with_message( 'bvf-vessels', array( 'action' => 'edit', 'vessel_id' => (string) $id ) );
			return;
		}

		$insert  = array(
			'name'        => $name,
			'external_id' => $external,
			'status'      => $status,
			'created_at'  => $now,
			'updated_at'  => $now,
		);
		$formats = array( '%s', '%s', '%s', '%s', '%s' );
		if ( $captain > 0 ) {
			$insert['assigned_captain_user_id'] = $captain;
			$formats[]                          = '%d';
		}

		$wpdb->insert( $table, $insert, $formats );
		$new_id = (int) $wpdb->insert_id;
		$this->redirect_with_message( 'bvf-vessels', array( 'action' => 'edit', 'vessel_id' => (string) $new_id ) );
	}

	/**
	 * Create trip.
	 */
	private function post_save_trip() {
		global $wpdb;
		$vessel_id  = isset( $_POST['vessel_id'] ) ? absint( $_POST['vessel_id'] ) : 0;
		$captain_id = isset( $_POST['captain_user_id'] ) ? absint( $_POST['captain_user_id'] ) : 0;
		if ( $vessel_id <= 0 || $captain_id <= 0 ) {
			return;
		}

		$status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'active';
		if ( ! in_array( $status, array( 'pending', 'active', 'completed', 'cancelled' ), true ) ) {
			$status = 'active';
		}

		$vessels = $this->t( 'vessels' );
		$exists  = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$vessels} WHERE id = %d", $vessel_id ) );
		if ( ! $exists ) {
			return;
		}

		$now    = current_time( 'mysql' );
		$origin = isset( $_POST['origin_label'] ) ? sanitize_text_field( wp_unslash( $_POST['origin_label'] ) ) : '';
		$dest   = isset( $_POST['destination_label'] ) ? sanitize_text_field( wp_unslash( $_POST['destination_label'] ) ) : '';

		$row     = array(
			'vessel_id'         => $vessel_id,
			'captain_user_id'   => $captain_id,
			'status'            => $status,
			'origin_label'      => $origin,
			'destination_label' => $dest,
		);
		$formats = array( '%d', '%d', '%s', '%s', '%s' );

		if ( 'active' === $status ) {
			$row['started_at'] = $now;
			$formats[]         = '%s';
		}

		$row['created_at'] = $now;
		$row['updated_at'] = $now;
		$formats[]         = '%s';
		$formats[]         = '%s';

		$trips = $this->t( 'trips' );
		$wpdb->insert( $trips, $row, $formats );

		if ( 'active' === $status ) {
			BVF_Fleet_Cache::bust();
		}

		$this->redirect_with_message( 'bvf-trips' );
	}

	/**
	 * Complete an active trip from admin.
	 */
	private function post_complete_trip() {
		global $wpdb;
		$trip_id = isset( $_POST['trip_id'] ) ? absint( $_POST['trip_id'] ) : 0;
		if ( $trip_id <= 0 ) {
			return;
		}
		$now   = current_time( 'mysql' );
		$trips = $this->t( 'trips' );
		$wpdb->update(
			$trips,
			array(
				'status'     => 'completed',
				'ended_at'   => $now,
				'updated_at' => $now,
			),
			array( 'id' => $trip_id ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);
		BVF_Fleet_Cache::bust();
		$this->redirect_with_message( 'bvf-trips' );
	}

	/**
	 * Add crew member.
	 */
	private function post_save_crew() {
		global $wpdb;
		$display = isset( $_POST['display_name'] ) ? sanitize_text_field( wp_unslash( $_POST['display_name'] ) ) : '';
		if ( '' === $display ) {
			return;
		}

		$role_slug = isset( $_POST['role_slug'] ) ? sanitize_key( wp_unslash( $_POST['role_slug'] ) ) : 'deckhand';
		$wp_uid    = isset( $_POST['wp_user_id'] ) ? absint( $_POST['wp_user_id'] ) : 0;
		$vessel_id = isset( $_POST['vessel_id'] ) ? absint( $_POST['vessel_id'] ) : 0;

		$now  = current_time( 'mysql' );
		$row  = array(
			'display_name' => $display,
			'role_slug'    => $role_slug,
			'created_at'   => $now,
			'updated_at'   => $now,
		);
		$fmt  = array( '%s', '%s', '%s', '%s' );

		if ( $wp_uid > 0 ) {
			$row['wp_user_id'] = $wp_uid;
			$fmt[]             = '%d';
		}
		if ( $vessel_id > 0 ) {
			$row['vessel_id'] = $vessel_id;
			$fmt[]            = '%d';
		}

		$wpdb->insert( $this->t( 'crew' ), $row, $fmt );
		$this->redirect_with_message( 'bvf-crew' );
	}

	/**
	 * Add fuel log entry.
	 */
	private function post_save_fuel() {
		global $wpdb;
		$trip_id = isset( $_POST['trip_id'] ) ? absint( $_POST['trip_id'] ) : 0;
		if ( $trip_id <= 0 ) {
			return;
		}

		$loaded   = isset( $_POST['fuel_loaded_litres'] ) && '' !== $_POST['fuel_loaded_litres'] ? (float) $_POST['fuel_loaded_litres'] : null;
		$consumed = isset( $_POST['fuel_consumed_litres'] ) && '' !== $_POST['fuel_consumed_litres'] ? (float) $_POST['fuel_consumed_litres'] : null;
		$notes    = isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['notes'] ) ) : '';

		$now  = current_time( 'mysql' );
		$row  = array(
			'trip_id'    => $trip_id,
			'user_id'    => get_current_user_id(),
			'notes'      => $notes,
			'created_at' => $now,
		);
		$fmt  = array( '%d', '%d', '%s', '%s' );
		if ( null !== $loaded ) {
			$row['fuel_loaded_litres'] = $loaded;
			$fmt[]                     = '%f';
		}
		if ( null !== $consumed ) {
			$row['fuel_consumed_litres'] = $consumed;
			$fmt[]                       = '%f';
		}

		$wpdb->insert( $this->t( 'fuel_logs' ), $row, $fmt );
		$this->redirect_with_message( 'bvf-fuel' );
	}

	/**
	 * Acknowledge an alert.
	 */
	private function post_ack_alert() {
		global $wpdb;
		$alert_id = isset( $_POST['alert_id'] ) ? absint( $_POST['alert_id'] ) : 0;
		if ( $alert_id <= 0 ) {
			return;
		}
		$now = current_time( 'mysql' );
		$wpdb->update(
			$this->t( 'alerts' ),
			array( 'acknowledged_at' => $now ),
			array( 'id' => $alert_id ),
			array( '%s' ),
			array( '%d' )
		);
		$this->redirect_with_message( 'bosvesfinder' );
	}

	/**
	 * Print success notice when ?bvf_msg=saved.
	 */
	private function maybe_notice_saved() {
		if ( ! isset( $_GET['bvf_msg'] ) || 'saved' !== sanitize_key( wp_unslash( $_GET['bvf_msg'] ) ) ) {
			return;
		}
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Changes saved.', 'bosvesfinder' ) . '</p></div>';
	}

	/**
	 * Dashboard: stats + recent alerts.
	 */
	public function render_dashboard() {
		if ( ! current_user_can( BVF_Roles::CAP_VIEW_FLEET ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'bosvesfinder' ) );
		}

		global $wpdb;
		$vessels = $this->t( 'vessels' );
		$trips   = $this->t( 'trips' );
		$crew    = $this->t( 'crew' );
		$alerts  = $this->t( 'alerts' );

		$active_vessels = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$vessels} WHERE status = 'active'" );
		$active_trips   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$trips} WHERE status = 'active'" );
		$crew_count     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$crew}" );
		$open_alerts    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$alerts} WHERE acknowledged_at IS NULL" );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$recent_alerts = $wpdb->get_results(
			"SELECT a.*, v.name AS vessel_name FROM {$alerts} a
			LEFT JOIN {$vessels} v ON v.id = a.vessel_id
			ORDER BY a.id DESC LIMIT 20",
			ARRAY_A
		);

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__( 'BOSVesFinder — Dashboard', 'bosvesfinder' ) . '</h1>';
		$this->maybe_notice_saved();

		echo '<div class="bvf-admin-stats">';
		$this->stat_card( (string) $active_vessels, __( 'Active vessels', 'bosvesfinder' ) );
		$this->stat_card( (string) $active_trips, __( 'Active trips', 'bosvesfinder' ) );
		$this->stat_card( (string) $crew_count, __( 'Crew records', 'bosvesfinder' ) );
		$this->stat_card( (string) $open_alerts, __( 'Open alerts', 'bosvesfinder' ) );
		echo '</div>';

		echo '<p><code>[bvf_fleet_map]</code> · <code>[bvf_fleet_map tracks="1" track_hours="48"]</code> · <code>[bvf_fleet_map heatmap="1"]</code> · <code>[bvf_captain_tracker]</code></p>';
		echo '<p><code>' . esc_html( rest_url( 'bosvesfinder/v1/' ) ) . '</code></p>';

		echo '<div class="bvf-admin-card"><h2>' . esc_html__( 'Recent alerts', 'bosvesfinder' ) . '</h2>';
		if ( empty( $recent_alerts ) ) {
			echo '<p>' . esc_html__( 'No alerts yet.', 'bosvesfinder' ) . '</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr>';
			echo '<th>' . esc_html__( 'When', 'bosvesfinder' ) . '</th>';
			echo '<th>' . esc_html__( 'Type', 'bosvesfinder' ) . '</th>';
			echo '<th>' . esc_html__( 'Severity', 'bosvesfinder' ) . '</th>';
			echo '<th>' . esc_html__( 'Vessel', 'bosvesfinder' ) . '</th>';
			echo '<th>' . esc_html__( 'Trip', 'bosvesfinder' ) . '</th>';
			if ( current_user_can( BVF_Roles::CAP_MANAGE_FLEET ) ) {
				echo '<th>' . esc_html__( 'Actions', 'bosvesfinder' ) . '</th>';
			}
			echo '</tr></thead><tbody>';
			foreach ( $recent_alerts as $a ) {
				$ack = ! empty( $a['acknowledged_at'] );
				echo '<tr>';
				echo '<td>' . esc_html( $a['created_at'] ) . '</td>';
				echo '<td>' . esc_html( $a['alert_type'] ) . '</td>';
				echo '<td><span class="bvf-badge bvf-badge--' . esc_attr( $a['severity'] === 'critical' ? 'critical' : 'pending' ) . '">' . esc_html( $a['severity'] ) . '</span></td>';
				echo '<td>' . esc_html( $a['vessel_name'] ? $a['vessel_name'] : '—' ) . '</td>';
				echo '<td>' . esc_html( $a['trip_id'] ? '#' . (int) $a['trip_id'] : '—' ) . '</td>';
				if ( current_user_can( BVF_Roles::CAP_MANAGE_FLEET ) ) {
					echo '<td>';
					if ( ! $ack ) {
						echo '<form method="post" style="display:inline">';
						wp_nonce_field( 'bvf_admin_ack_alert', '_bvf_admin_nonce' );
						echo '<input type="hidden" name="bvf_admin_action" value="ack_alert" />';
						echo '<input type="hidden" name="alert_id" value="' . esc_attr( (string) (int) $a['id'] ) . '" />';
						submit_button( __( 'Acknowledge', 'bosvesfinder' ), 'small secondary', 'submit', false );
						echo '</form>';
					} else {
						esc_html_e( 'Acknowledged', 'bosvesfinder' );
					}
					echo '</td>';
				}
				echo '</tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div></div>';
	}

	/**
	 * @param string $value Stat value.
	 * @param string $label Label.
	 */
	private function stat_card( $value, $label ) {
		echo '<div class="bvf-admin-stat"><p class="bvf-admin-stat__value">' . esc_html( $value ) . '</p>';
		echo '<p class="bvf-admin-stat__label">' . esc_html( $label ) . '</p></div>';
	}

	/**
	 * Vessels list + add/edit form.
	 */
	public function render_vessels() {
		if ( ! current_user_can( BVF_Roles::CAP_VIEW_FLEET ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'bosvesfinder' ) );
		}

		global $wpdb;
		$table = $this->t( 'vessels' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY name ASC", ARRAY_A );

		$action   = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '';
		$edit_id  = isset( $_GET['vessel_id'] ) ? absint( $_GET['vessel_id'] ) : 0;
		$editing  = ( 'edit' === $action && $edit_id > 0 );
		$vessel   = null;
		if ( $editing ) {
			$vessel = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $edit_id ), ARRAY_A );
			if ( ! $vessel ) {
				$editing = false;
			}
		}

		$can_manage = current_user_can( BVF_Roles::CAP_MANAGE_FLEET );

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__( 'Vessels', 'bosvesfinder' ) . '</h1>';
		$this->maybe_notice_saved();

		if ( $can_manage ) {
			echo '<div class="bvf-admin-card bvf-admin-form"><h2>' . ( $editing ? esc_html__( 'Edit vessel', 'bosvesfinder' ) : esc_html__( 'Add vessel', 'bosvesfinder' ) ) . '</h2>';
			echo '<form method="post">';
			wp_nonce_field( 'bvf_admin_save_vessel', '_bvf_admin_nonce' );
			echo '<input type="hidden" name="bvf_admin_action" value="save_vessel" />';
			if ( $editing ) {
				echo '<input type="hidden" name="vessel_id" value="' . esc_attr( (string) (int) $vessel['id'] ) . '" />';
			}
			echo '<table class="form-table"><tbody>';
			echo '<tr><th><label for="bvf-v-name">' . esc_html__( 'Name', 'bosvesfinder' ) . '</label></th><td>';
			echo '<input name="name" id="bvf-v-name" type="text" class="regular-text" required value="' . esc_attr( $editing ? $vessel['name'] : '' ) . '" /></td></tr>';
			echo '<tr><th><label for="bvf-v-ext">' . esc_html__( 'External ID', 'bosvesfinder' ) . '</label></th><td>';
			echo '<input name="external_id" id="bvf-v-ext" type="text" class="regular-text" value="' . esc_attr( $editing ? $vessel['external_id'] : '' ) . '" /></td></tr>';
			echo '<tr><th><label for="bvf-v-status">' . esc_html__( 'Status', 'bosvesfinder' ) . '</label></th><td>';
			$st = $editing ? $vessel['status'] : 'active';
			echo '<select name="status" id="bvf-v-status">';
			foreach ( array( 'active', 'inactive', 'maintenance' ) as $opt ) {
				echo '<option value="' . esc_attr( $opt ) . '"' . selected( $st, $opt, false ) . '>' . esc_html( $opt ) . '</option>';
			}
			echo '</select></td></tr>';
			echo '<tr><th><label for="bvf-v-cap">' . esc_html__( 'Assigned captain (WP user)', 'bosvesfinder' ) . '</label></th><td>';
			echo '<select name="assigned_captain_user_id" id="bvf-v-cap"><option value="0">' . esc_html__( '— None —', 'bosvesfinder' ) . '</option>';
			$sel = $editing && ! empty( $vessel['assigned_captain_user_id'] ) ? (int) $vessel['assigned_captain_user_id'] : 0;
			foreach ( $this->get_captain_choices() as $u ) {
				echo '<option value="' . esc_attr( (string) $u->ID ) . '"' . selected( $sel, $u->ID, false ) . '>' . esc_html( $u->display_name ) . '</option>';
			}
			echo '</select></td></tr>';
			echo '</tbody></table>';
			submit_button( $editing ? __( 'Update vessel', 'bosvesfinder' ) : __( 'Add vessel', 'bosvesfinder' ) );
			echo '</form></div>';
		}

		echo '<h2 class="title">' . esc_html__( 'Fleet registry', 'bosvesfinder' ) . '</h2>';
		echo '<table class="widefat striped"><thead><tr>';
		echo '<th>' . esc_html__( 'ID', 'bosvesfinder' ) . '</th>';
		echo '<th>' . esc_html__( 'Name', 'bosvesfinder' ) . '</th>';
		echo '<th>' . esc_html__( 'Status', 'bosvesfinder' ) . '</th>';
		echo '<th>' . esc_html__( 'Captain', 'bosvesfinder' ) . '</th>';
		if ( $can_manage ) {
			echo '<th>' . esc_html__( 'Actions', 'bosvesfinder' ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		if ( empty( $rows ) ) {
			$cspan = $can_manage ? 5 : 4;
			echo '<tr><td colspan="' . esc_attr( (string) $cspan ) . '">' . esc_html__( 'No vessels yet.', 'bosvesfinder' ) . '</td></tr>';
		} else {
			foreach ( $rows as $r ) {
				$cap_id = ! empty( $r['assigned_captain_user_id'] ) ? (int) $r['assigned_captain_user_id'] : 0;
				echo '<tr>';
				echo '<td>' . esc_html( (string) (int) $r['id'] ) . '</td>';
				echo '<td>' . esc_html( $r['name'] ) . '</td>';
				echo '<td><span class="bvf-badge bvf-badge--' . esc_attr( 'active' === $r['status'] ? 'active' : 'completed' ) . '">' . esc_html( $r['status'] ) . '</span></td>';
				echo '<td>' . esc_html( $cap_id ? $this->user_display_name( $cap_id ) : '—' ) . '</td>';
				if ( $can_manage ) {
					$url = add_query_arg(
						array(
							'page'      => 'bvf-vessels',
							'action'    => 'edit',
							'vessel_id' => (int) $r['id'],
						),
						admin_url( 'admin.php' )
					);
					echo '<td><a href="' . esc_url( $url ) . '">' . esc_html__( 'Edit', 'bosvesfinder' ) . '</a></td>';
				}
				echo '</tr>';
			}
		}
		echo '</tbody></table></div>';
	}

	/**
	 * Trips list + create form.
	 */
	public function render_trips() {
		if ( ! current_user_can( BVF_Roles::CAP_VIEW_FLEET ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'bosvesfinder' ) );
		}

		global $wpdb;
		$trips   = $this->t( 'trips' );
		$vessels = $this->t( 'vessels' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			"SELECT t.*, v.name AS vessel_name FROM {$trips} t
			INNER JOIN {$vessels} v ON v.id = t.vessel_id
			ORDER BY t.id DESC LIMIT 200",
			ARRAY_A
		);

		$can_manage = current_user_can( BVF_Roles::CAP_MANAGE_FLEET );
		$vessel_rows = $wpdb->get_results( "SELECT id, name FROM {$vessels} ORDER BY name ASC", ARRAY_A );

		echo '<div class="wrap"><h1>' . esc_html__( 'Trips', 'bosvesfinder' ) . '</h1>';
		$this->maybe_notice_saved();

		if ( $can_manage ) {
			echo '<div class="bvf-admin-card bvf-admin-form"><h2>' . esc_html__( 'Create trip', 'bosvesfinder' ) . '</h2>';
			echo '<form method="post">';
			wp_nonce_field( 'bvf_admin_save_trip', '_bvf_admin_nonce' );
			echo '<input type="hidden" name="bvf_admin_action" value="save_trip" />';
			echo '<table class="form-table"><tbody>';
			echo '<tr><th><label for="bvf-t-vessel">' . esc_html__( 'Vessel', 'bosvesfinder' ) . '</label></th><td>';
			echo '<select name="vessel_id" id="bvf-t-vessel" required>';
			echo '<option value="">' . esc_html__( 'Select vessel…', 'bosvesfinder' ) . '</option>';
			foreach ( $vessel_rows as $v ) {
				echo '<option value="' . esc_attr( (string) (int) $v['id'] ) . '">' . esc_html( $v['name'] ) . '</option>';
			}
			echo '</select></td></tr>';
			echo '<tr><th><label for="bvf-t-cap">' . esc_html__( 'Captain', 'bosvesfinder' ) . '</label></th><td>';
			echo '<select name="captain_user_id" id="bvf-t-cap" required>';
			echo '<option value="">' . esc_html__( 'Select captain…', 'bosvesfinder' ) . '</option>';
			foreach ( $this->get_captain_choices() as $u ) {
				echo '<option value="' . esc_attr( (string) $u->ID ) . '">' . esc_html( $u->display_name ) . '</option>';
			}
			echo '</select></td></tr>';
			echo '<tr><th><label for="bvf-t-status">' . esc_html__( 'Initial status', 'bosvesfinder' ) . '</label></th><td>';
			echo '<select name="status" id="bvf-t-status">';
			foreach ( array( 'active', 'pending' ) as $opt ) {
				echo '<option value="' . esc_attr( $opt ) . '"' . selected( 'active', $opt, false ) . '>' . esc_html( $opt ) . '</option>';
			}
			echo '</select></td></tr>';
			echo '<tr><th><label for="bvf-t-o">' . esc_html__( 'Origin', 'bosvesfinder' ) . '</label></th><td>';
			echo '<input name="origin_label" id="bvf-t-o" type="text" class="regular-text" /></td></tr>';
			echo '<tr><th><label for="bvf-t-d">' . esc_html__( 'Destination', 'bosvesfinder' ) . '</label></th><td>';
			echo '<input name="destination_label" id="bvf-t-d" type="text" class="regular-text" /></td></tr>';
			echo '</tbody></table>';
			submit_button( __( 'Create trip', 'bosvesfinder' ) );
			echo '</form></div>';
		}

		echo '<h2 class="title">' . esc_html__( 'Trip log', 'bosvesfinder' ) . '</h2>';
		echo '<table class="widefat striped"><thead><tr>';
		echo '<th>ID</th><th>' . esc_html__( 'Vessel', 'bosvesfinder' ) . '</th><th>' . esc_html__( 'Captain', 'bosvesfinder' ) . '</th>';
		echo '<th>' . esc_html__( 'Status', 'bosvesfinder' ) . '</th><th>' . esc_html__( 'Started', 'bosvesfinder' ) . '</th><th>' . esc_html__( 'Ended', 'bosvesfinder' ) . '</th>';
		if ( $can_manage ) {
			echo '<th>' . esc_html__( 'Actions', 'bosvesfinder' ) . '</th>';
		}
		echo '</tr></thead><tbody>';

		if ( empty( $rows ) ) {
			$cspan = $can_manage ? 7 : 6;
			echo '<tr><td colspan="' . esc_attr( (string) $cspan ) . '">' . esc_html__( 'No trips yet.', 'bosvesfinder' ) . '</td></tr>';
		} else {
			foreach ( $rows as $r ) {
				$badge = 'completed' === $r['status'] ? 'completed' : ( 'active' === $r['status'] ? 'active' : 'pending' );
				echo '<tr>';
				echo '<td>' . esc_html( (string) (int) $r['id'] ) . '</td>';
				echo '<td>' . esc_html( $r['vessel_name'] ) . '</td>';
				echo '<td>' . esc_html( $this->user_display_name( (int) $r['captain_user_id'] ) ) . '</td>';
				echo '<td><span class="bvf-badge bvf-badge--' . esc_attr( $badge ) . '">' . esc_html( $r['status'] ) . '</span></td>';
				echo '<td>' . esc_html( $r['started_at'] ? $r['started_at'] : '—' ) . '</td>';
				echo '<td>' . esc_html( $r['ended_at'] ? $r['ended_at'] : '—' ) . '</td>';
				if ( $can_manage ) {
					echo '<td class="bvf-admin-actions">';
					if ( 'active' === $r['status'] ) {
						echo '<form method="post" style="display:inline">';
						wp_nonce_field( 'bvf_admin_complete_trip', '_bvf_admin_nonce' );
						echo '<input type="hidden" name="bvf_admin_action" value="complete_trip" />';
						echo '<input type="hidden" name="trip_id" value="' . esc_attr( (string) (int) $r['id'] ) . '" />';
						submit_button( __( 'Complete', 'bosvesfinder' ), 'small', 'submit', false );
						echo '</form>';
					} else {
						echo '—';
					}
					echo '</td>';
				}
				echo '</tr>';
			}
		}
		echo '</tbody></table></div>';
	}

	/**
	 * Crew list + add form.
	 */
	public function render_crew() {
		if ( ! current_user_can( BVF_Roles::CAP_VIEW_FLEET ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'bosvesfinder' ) );
		}

		global $wpdb;
		$crew    = $this->t( 'crew' );
		$vessels = $this->t( 'vessels' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			"SELECT c.*, v.name AS vessel_name FROM {$crew} c
			LEFT JOIN {$vessels} v ON v.id = c.vessel_id
			ORDER BY c.display_name ASC",
			ARRAY_A
		);

		$can_manage   = current_user_can( BVF_Roles::CAP_MANAGE_FLEET );
		$vessel_rows = $wpdb->get_results( "SELECT id, name FROM {$vessels} ORDER BY name ASC", ARRAY_A );

		echo '<div class="wrap"><h1>' . esc_html__( 'Crew', 'bosvesfinder' ) . '</h1>';
		$this->maybe_notice_saved();

		if ( $can_manage ) {
			echo '<div class="bvf-admin-card bvf-admin-form"><h2>' . esc_html__( 'Add crew member', 'bosvesfinder' ) . '</h2>';
			echo '<form method="post">';
			wp_nonce_field( 'bvf_admin_save_crew', '_bvf_admin_nonce' );
			echo '<input type="hidden" name="bvf_admin_action" value="save_crew" />';
			echo '<table class="form-table"><tbody>';
			echo '<tr><th><label for="bvf-c-name">' . esc_html__( 'Display name', 'bosvesfinder' ) . '</label></th><td>';
			echo '<input name="display_name" id="bvf-c-name" type="text" class="regular-text" required /></td></tr>';
			echo '<tr><th><label for="bvf-c-role">' . esc_html__( 'Role', 'bosvesfinder' ) . '</label></th><td>';
			echo '<select name="role_slug" id="bvf-c-role">';
			foreach ( array( 'captain', 'engineer', 'deckhand', 'other' ) as $role ) {
				echo '<option value="' . esc_attr( $role ) . '">' . esc_html( $role ) . '</option>';
			}
			echo '</select></td></tr>';
			echo '<tr><th><label for="bvf-c-wp">' . esc_html__( 'Linked WP user (optional)', 'bosvesfinder' ) . '</label></th><td>';
			echo '<select name="wp_user_id" id="bvf-c-wp"><option value="0">' . esc_html__( '— None —', 'bosvesfinder' ) . '</option>';
			foreach ( get_users( array( 'orderby' => 'display_name' ) ) as $u ) {
				echo '<option value="' . esc_attr( (string) $u->ID ) . '">' . esc_html( $u->display_name ) . '</option>';
			}
			echo '</select></td></tr>';
			echo '<tr><th><label for="bvf-c-v">' . esc_html__( 'Assigned vessel (optional)', 'bosvesfinder' ) . '</label></th><td>';
			echo '<select name="vessel_id" id="bvf-c-v"><option value="0">' . esc_html__( '— None —', 'bosvesfinder' ) . '</option>';
			foreach ( $vessel_rows as $v ) {
				echo '<option value="' . esc_attr( (string) (int) $v['id'] ) . '">' . esc_html( $v['name'] ) . '</option>';
			}
			echo '</select></td></tr>';
			echo '</tbody></table>';
			submit_button( __( 'Add crew', 'bosvesfinder' ) );
			echo '</form></div>';
		}

		echo '<h2 class="title">' . esc_html__( 'Crew registry', 'bosvesfinder' ) . '</h2>';
		echo '<table class="widefat striped"><thead><tr>';
		echo '<th>ID</th><th>' . esc_html__( 'Name', 'bosvesfinder' ) . '</th><th>' . esc_html__( 'Role', 'bosvesfinder' ) . '</th>';
		echo '<th>' . esc_html__( 'WP user', 'bosvesfinder' ) . '</th><th>' . esc_html__( 'Vessel', 'bosvesfinder' ) . '</th>';
		echo '</tr></thead><tbody>';
		if ( empty( $rows ) ) {
			echo '<tr><td colspan="5">' . esc_html__( 'No crew yet.', 'bosvesfinder' ) . '</td></tr>';
		} else {
			foreach ( $rows as $r ) {
				$wp = ! empty( $r['wp_user_id'] ) ? (int) $r['wp_user_id'] : 0;
				echo '<tr>';
				echo '<td>' . esc_html( (string) (int) $r['id'] ) . '</td>';
				echo '<td>' . esc_html( $r['display_name'] ) . '</td>';
				echo '<td>' . esc_html( $r['role_slug'] ) . '</td>';
				echo '<td>' . esc_html( $wp ? $this->user_display_name( $wp ) : '—' ) . '</td>';
				echo '<td>' . esc_html( $r['vessel_name'] ? $r['vessel_name'] : '—' ) . '</td>';
				echo '</tr>';
			}
		}
		echo '</tbody></table></div>';
	}

	/**
	 * Fuel logs + add form.
	 */
	public function render_fuel() {
		if ( ! current_user_can( BVF_Roles::CAP_VIEW_FLEET ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'bosvesfinder' ) );
		}

		global $wpdb;
		$fuel    = $this->t( 'fuel_logs' );
		$trips   = $this->t( 'trips' );
		$vessels = $this->t( 'vessels' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			"SELECT f.*, t.vessel_id, v.name AS vessel_name, t.status AS trip_status
			FROM {$fuel} f
			INNER JOIN {$trips} t ON t.id = f.trip_id
			INNER JOIN {$vessels} v ON v.id = t.vessel_id
			ORDER BY f.id DESC LIMIT 150",
			ARRAY_A
		);

		$can_manage = current_user_can( BVF_Roles::CAP_MANAGE_FLEET );
		$trip_opts  = $wpdb->get_results(
			"SELECT t.id, t.status, v.name AS vessel_name FROM {$trips} t
			INNER JOIN {$vessels} v ON v.id = t.vessel_id
			ORDER BY t.id DESC LIMIT 300",
			ARRAY_A
		);

		echo '<div class="wrap"><h1>' . esc_html__( 'Fuel logs', 'bosvesfinder' ) . '</h1>';
		$this->maybe_notice_saved();

		if ( $can_manage ) {
			echo '<div class="bvf-admin-card bvf-admin-form"><h2>' . esc_html__( 'Add fuel entry', 'bosvesfinder' ) . '</h2>';
			echo '<form method="post">';
			wp_nonce_field( 'bvf_admin_save_fuel', '_bvf_admin_nonce' );
			echo '<input type="hidden" name="bvf_admin_action" value="save_fuel" />';
			echo '<table class="form-table"><tbody>';
			echo '<tr><th><label for="bvf-f-trip">' . esc_html__( 'Trip', 'bosvesfinder' ) . '</label></th><td>';
			echo '<select name="trip_id" id="bvf-f-trip" required>';
			echo '<option value="">' . esc_html__( 'Select trip…', 'bosvesfinder' ) . '</option>';
			foreach ( $trip_opts as $t ) {
				$label = '#' . (int) $t['id'] . ' — ' . $t['vessel_name'] . ' (' . $t['status'] . ')';
				echo '<option value="' . esc_attr( (string) (int) $t['id'] ) . '">' . esc_html( $label ) . '</option>';
			}
			echo '</select></td></tr>';
			echo '<tr><th><label for="bvf-f-load">' . esc_html__( 'Fuel loaded (L)', 'bosvesfinder' ) . '</label></th><td>';
			echo '<input name="fuel_loaded_litres" id="bvf-f-load" type="number" step="0.001" class="small-text" /></td></tr>';
			echo '<tr><th><label for="bvf-f-use">' . esc_html__( 'Fuel consumed (L)', 'bosvesfinder' ) . '</label></th><td>';
			echo '<input name="fuel_consumed_litres" id="bvf-f-use" type="number" step="0.001" class="small-text" /></td></tr>';
			echo '<tr><th><label for="bvf-f-notes">' . esc_html__( 'Notes', 'bosvesfinder' ) . '</label></th><td>';
			echo '<textarea name="notes" id="bvf-f-notes" class="large-text" rows="3"></textarea></td></tr>';
			echo '</tbody></table>';
			submit_button( __( 'Save fuel log', 'bosvesfinder' ) );
			echo '</form></div>';
		}

		echo '<h2 class="title">' . esc_html__( 'Recent entries', 'bosvesfinder' ) . '</h2>';
		echo '<table class="widefat striped"><thead><tr>';
		echo '<th>ID</th><th>' . esc_html__( 'Trip', 'bosvesfinder' ) . '</th><th>' . esc_html__( 'Vessel', 'bosvesfinder' ) . '</th>';
		echo '<th>' . esc_html__( 'Loaded (L)', 'bosvesfinder' ) . '</th><th>' . esc_html__( 'Consumed (L)', 'bosvesfinder' ) . '</th>';
		echo '<th>' . esc_html__( 'When', 'bosvesfinder' ) . '</th>';
		echo '</tr></thead><tbody>';
		if ( empty( $rows ) ) {
			echo '<tr><td colspan="6">' . esc_html__( 'No fuel logs yet.', 'bosvesfinder' ) . '</td></tr>';
		} else {
			foreach ( $rows as $r ) {
				echo '<tr>';
				echo '<td>' . esc_html( (string) (int) $r['id'] ) . '</td>';
				echo '<td>#' . esc_html( (string) (int) $r['trip_id'] ) . '</td>';
				echo '<td>' . esc_html( $r['vessel_name'] ) . '</td>';
				echo '<td>' . esc_html( null !== $r['fuel_loaded_litres'] ? (string) $r['fuel_loaded_litres'] : '—' ) . '</td>';
				echo '<td>' . esc_html( null !== $r['fuel_consumed_litres'] ? (string) $r['fuel_consumed_litres'] : '—' ) . '</td>';
				echo '<td>' . esc_html( $r['created_at'] ) . '</td>';
				echo '</tr>';
			}
		}
		echo '</tbody></table></div>';
	}

	/**
	 * CSV download for reports (early exit).
	 */
	public function maybe_export_csv() {
		if ( ! isset( $_GET['page'] ) || 'bvf-reports' !== sanitize_key( wp_unslash( $_GET['page'] ) ) ) {
			return;
		}
		if ( empty( $_GET['bvf_export'] ) || empty( $_GET['_wpnonce'] ) ) {
			return;
		}
		if ( ! current_user_can( BVF_Roles::CAP_VIEW_FLEET ) ) {
			return;
		}
		$export = sanitize_key( wp_unslash( $_GET['bvf_export'] ) );
		if ( ! in_array( $export, array( 'trips', 'alerts' ), true ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'bvf_export_' . $export ) ) {
			return;
		}

		global $wpdb;
		list( $from, $to ) = $this->get_report_date_range_from_get();

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		/* translators: %s: export type */
		$fname = 'bvf-' . $export . '-' . $from . '-to-' . $to . '.csv';
		header( 'Content-Disposition: attachment; filename="' . $fname . '"' );

		$out = fopen( 'php://output', 'w' );
		if ( false === $out ) {
			exit;
		}

		fprintf( $out, chr( 0xef ) . chr( 0xbb ) . chr( 0xbf ) );

		if ( 'trips' === $export ) {
			$this->output_trips_csv( $out, $from, $to );
		} else {
			$this->output_alerts_csv( $out, $from, $to );
		}

		fclose( $out );
		exit;
	}

	/**
	 * GET delete geofence (with nonce).
	 */
	public function maybe_delete_geofence() {
		if ( empty( $_GET['page'] ) || 'bvf-geofences' !== sanitize_key( wp_unslash( $_GET['page'] ) ) ) {
			return;
		}
		if ( empty( $_GET['action'] ) || 'delete' !== sanitize_key( wp_unslash( $_GET['action'] ) ) ) {
			return;
		}
		if ( ! current_user_can( BVF_Roles::CAP_MANAGE_FLEET ) ) {
			return;
		}
		$id = isset( $_GET['geofence_id'] ) ? absint( $_GET['geofence_id'] ) : 0;
		if ( $id <= 0 || empty( $_GET['_wpnonce'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'bvf_delete_geofence_' . $id ) ) {
			return;
		}

		global $wpdb;
		$wpdb->delete( $this->t( 'geofences' ), array( 'id' => $id ), array( '%d' ) );
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => 'bvf-geofences',
					'bvf_msg' => 'saved',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Save or update geofence.
	 */
	private function post_save_geofence() {
		global $wpdb;
		$table = $this->t( 'geofences' );
		$now   = current_time( 'mysql' );

		$id = isset( $_POST['geofence_id'] ) ? absint( $_POST['geofence_id'] ) : 0;
		$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		if ( '' === $name ) {
			return;
		}

		$zone = isset( $_POST['zone_type'] ) ? sanitize_key( wp_unslash( $_POST['zone_type'] ) ) : 'operational';
		if ( ! in_array( $zone, array( 'operational', 'restricted' ), true ) ) {
			$zone = 'operational';
		}

		$lat    = isset( $_POST['center_lat'] ) && '' !== $_POST['center_lat'] ? (float) $_POST['center_lat'] : null;
		$lng    = isset( $_POST['center_lng'] ) && '' !== $_POST['center_lng'] ? (float) $_POST['center_lng'] : null;
		$radius = isset( $_POST['radius_meters'] ) && '' !== $_POST['radius_meters'] ? absint( $_POST['radius_meters'] ) : null;
		$active = ! empty( $_POST['active'] ) ? 1 : 0;

		$clat = ( null !== $lat && $lat >= -90 && $lat <= 90 ) ? (string) round( $lat, 7 ) : null;
		$clng = ( null !== $lng && $lng >= -180 && $lng <= 180 ) ? (string) round( $lng, 7 ) : null;
		$rad  = ( $radius && $radius > 0 ) ? $radius : null;

		$row = array(
			'name'           => $name,
			'zone_type'      => $zone,
			'active'         => $active,
			'updated_at'     => $now,
			'center_lat'     => $clat,
			'center_lng'     => $clng,
			'radius_meters'  => $rad,
		);

		if ( $id > 0 ) {
			$wpdb->update(
				$table,
				$row,
				array( 'id' => $id ),
				array( '%s', '%s', '%d', '%s', '%s', '%s', '%d' ),
				array( '%d' )
			);
			$this->redirect_with_message( 'bvf-geofences', array( 'action' => 'edit', 'geofence_id' => (string) $id ) );
			return;
		}

		$row['created_at'] = $now;
		$wpdb->insert(
			$table,
			$row,
			array( '%s', '%s', '%d', '%s', '%s', '%s', '%d', '%s' )
		);
		$new_id = (int) $wpdb->insert_id;
		$this->redirect_with_message( 'bvf-geofences', array( 'action' => 'edit', 'geofence_id' => (string) $new_id ) );
	}

	/**
	 * Notification and email options.
	 */
	private function post_save_settings() {
		$emails = isset( $_POST['bvf_ops_notification_emails'] )
			? sanitize_textarea_field( wp_unslash( $_POST['bvf_ops_notification_emails'] ) )
			: '';
		update_option( 'bvf_ops_notification_emails', $emails );
		update_option( 'bvf_email_geofence', ! empty( $_POST['bvf_email_geofence'] ) ? '1' : '0' );
		update_option( 'bvf_email_signal_loss', ! empty( $_POST['bvf_email_signal_loss'] ) ? '1' : '0' );
		$this->redirect_with_message( 'bvf-settings' );
	}

	/**
	 * Date range from GET (reports).
	 *
	 * @return array{0:string,1:string} Y-m-d
	 */
	private function get_report_date_range_from_get() {
		$to = isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : '';
		$from = isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : '';
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) ) {
			$to = gmdate( 'Y-m-d' );
		}
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ) {
			$from = gmdate( 'Y-m-d', strtotime( '-30 days' ) );
		}
		if ( strtotime( $from ) > strtotime( $to ) ) {
			$t    = $from;
			$from = $to;
			$to   = $t;
		}
		return array( $from, $to );
	}

	/**
	 * @param resource $out     Output stream.
	 * @param string   $date_from Y-m-d.
	 * @param string   $date_to   Y-m-d.
	 */
	private function output_trips_csv( $out, $date_from, $date_to ) {
		global $wpdb;
		$trips   = $this->t( 'trips' );
		$vessels = $this->t( 'vessels' );
		$logs    = $this->t( 'location_logs' );
		$fuel    = $this->t( 'fuel_logs' );

		fputcsv(
			$out,
			array(
				'ID',
				'Vessel',
				'Captain user ID',
				'Captain name',
				'Status',
				'Origin',
				'Destination',
				'Started',
				'Ended',
				'GPS points',
				'Track NM (approx)',
				'Fuel consumed L (sum)',
			)
		);

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sql = "SELECT t.*, v.name AS vessel_name,
			(SELECT COUNT(*) FROM {$logs} l WHERE l.trip_id = t.id) AS point_count,
			(SELECT COALESCE(SUM(f.fuel_consumed_litres),0) FROM {$fuel} f WHERE f.trip_id = t.id) AS fuel_sum
			FROM {$trips} t
			INNER JOIN {$vessels} v ON v.id = t.vessel_id
			WHERE DATE(COALESCE(t.started_at, t.created_at)) BETWEEN %s AND %s
			ORDER BY t.id DESC";

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $date_from, $date_to ), ARRAY_A );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		foreach ( $rows as $r ) {
			$nm = BVF_Geofence::trip_distance_nm( (int) $r['id'] );
			fputcsv(
				$out,
				array(
					$r['id'],
					$r['vessel_name'],
					$r['captain_user_id'],
					$this->user_display_name( (int) $r['captain_user_id'] ),
					$r['status'],
					$r['origin_label'],
					$r['destination_label'],
					$r['started_at'],
					$r['ended_at'],
					$r['point_count'],
					$nm,
					$r['fuel_sum'],
				)
			);
		}
	}

	/**
	 * @param resource $out       Output stream.
	 * @param string   $date_from Y-m-d.
	 * @param string   $date_to   Y-m-d.
	 */
	private function output_alerts_csv( $out, $date_from, $date_to ) {
		global $wpdb;
		$al      = $this->t( 'alerts' );
		$vessels = $this->t( 'vessels' );

		fputcsv(
			$out,
			array(
				'ID',
				'Type',
				'Severity',
				'Vessel',
				'Trip ID',
				'User ID',
				'Created',
				'Acknowledged',
				'Payload',
			)
		);

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table names from prefix.
		$sql = "SELECT a.*, v.name AS vessel_name FROM {$al} a
			LEFT JOIN {$vessels} v ON v.id = a.vessel_id
			WHERE DATE(a.created_at) BETWEEN %s AND %s
			ORDER BY a.id DESC";

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $date_from, $date_to ), ARRAY_A );

		foreach ( $rows as $r ) {
			fputcsv(
				$out,
				array(
					$r['id'],
					$r['alert_type'],
					$r['severity'],
					$r['vessel_name'] ? $r['vessel_name'] : '',
					$r['trip_id'],
					$r['user_id'],
					$r['created_at'],
					$r['acknowledged_at'],
					$r['payload'],
				)
			);
		}
	}

	/**
	 * Geofence CRUD UI.
	 */
	public function render_geofences() {
		if ( ! current_user_can( BVF_Roles::CAP_VIEW_FLEET ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'bosvesfinder' ) );
		}

		global $wpdb;
		$table = $this->t( 'geofences' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$list = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY name ASC", ARRAY_A );

		$can_manage = current_user_can( BVF_Roles::CAP_MANAGE_FLEET );
		$action     = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '';
		$edit_id    = isset( $_GET['geofence_id'] ) ? absint( $_GET['geofence_id'] ) : 0;
		$editing    = ( 'edit' === $action && $edit_id > 0 );
		$zone       = null;
		if ( $editing ) {
			$zone = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $edit_id ), ARRAY_A );
			if ( ! $zone ) {
				$editing = false;
			}
		}

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__( 'Geofences', 'bosvesfinder' ) . '</h1>';
		$this->maybe_notice_saved();

		if ( $can_manage ) {
			echo '<div class="bvf-admin-card bvf-admin-form"><h2>';
			echo $editing ? esc_html__( 'Edit zone', 'bosvesfinder' ) : esc_html__( 'Add zone', 'bosvesfinder' );
			echo '</h2><p class="description">';
			esc_html_e( 'Operational: alert when the vessel leaves the circle. Restricted: alert when the vessel enters the circle. Uses center latitude/longitude and radius in metres.', 'bosvesfinder' );
			echo '</p><form method="post">';
			wp_nonce_field( 'bvf_admin_save_geofence', '_bvf_admin_nonce' );
			echo '<input type="hidden" name="bvf_admin_action" value="save_geofence" />';
			if ( $editing ) {
				echo '<input type="hidden" name="geofence_id" value="' . esc_attr( (string) (int) $zone['id'] ) . '" />';
			}
			echo '<table class="form-table"><tbody>';
			echo '<tr><th><label for="bvf-g-name">' . esc_html__( 'Name', 'bosvesfinder' ) . '</label></th><td>';
			echo '<input name="name" id="bvf-g-name" type="text" class="regular-text" required value="' . esc_attr( $editing ? $zone['name'] : '' ) . '" /></td></tr>';
			echo '<tr><th><label for="bvf-g-type">' . esc_html__( 'Zone type', 'bosvesfinder' ) . '</label></th><td><select name="zone_type" id="bvf-g-type">';
			$zt = $editing ? $zone['zone_type'] : 'operational';
			foreach ( array( 'operational' => __( 'Operational (must stay inside)', 'bosvesfinder' ), 'restricted' => __( 'Restricted (must stay outside)', 'bosvesfinder' ) ) as $k => $lab ) {
				echo '<option value="' . esc_attr( $k ) . '"' . selected( $zt, $k, false ) . '>' . esc_html( $lab ) . '</option>';
			}
			echo '</select></td></tr>';
			echo '<tr><th><label for="bvf-g-lat">' . esc_html__( 'Center latitude', 'bosvesfinder' ) . '</label></th><td>';
			echo '<input name="center_lat" id="bvf-g-lat" type="text" class="regular-text" value="' . esc_attr( $editing && null !== $zone['center_lat'] ? (string) $zone['center_lat'] : '' ) . '" /></td></tr>';
			echo '<tr><th><label for="bvf-g-lng">' . esc_html__( 'Center longitude', 'bosvesfinder' ) . '</label></th><td>';
			echo '<input name="center_lng" id="bvf-g-lng" type="text" class="regular-text" value="' . esc_attr( $editing && null !== $zone['center_lng'] ? (string) $zone['center_lng'] : '' ) . '" /></td></tr>';
			echo '<tr><th><label for="bvf-g-r">' . esc_html__( 'Radius (m)', 'bosvesfinder' ) . '</label></th><td>';
			echo '<input name="radius_meters" id="bvf-g-r" type="number" min="1" class="small-text" value="' . esc_attr( $editing && $zone['radius_meters'] ? (string) (int) $zone['radius_meters'] : '' ) . '" /></td></tr>';
			echo '<tr><th>' . esc_html__( 'Active', 'bosvesfinder' ) . '</th><td><label><input name="active" type="checkbox" value="1" ' . checked( ! $editing || ! empty( $zone['active'] ), true, false ) . ' /> ';
			esc_html_e( 'Enforce this zone', 'bosvesfinder' );
			echo '</label></td></tr>';
			echo '</tbody></table>';
			submit_button( $editing ? __( 'Update zone', 'bosvesfinder' ) : __( 'Add zone', 'bosvesfinder' ) );
			echo '</form></div>';
		}

		echo '<h2 class="title">' . esc_html__( 'Defined zones', 'bosvesfinder' ) . '</h2>';
		echo '<table class="widefat striped"><thead><tr>';
		echo '<th>ID</th><th>' . esc_html__( 'Name', 'bosvesfinder' ) . '</th><th>' . esc_html__( 'Type', 'bosvesfinder' ) . '</th>';
		echo '<th>' . esc_html__( 'Center', 'bosvesfinder' ) . '</th><th>' . esc_html__( 'Radius m', 'bosvesfinder' ) . '</th><th>' . esc_html__( 'Active', 'bosvesfinder' ) . '</th>';
		if ( $can_manage ) {
			echo '<th>' . esc_html__( 'Actions', 'bosvesfinder' ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		if ( empty( $list ) ) {
			$cspan = $can_manage ? 7 : 6;
			echo '<tr><td colspan="' . esc_attr( (string) $cspan ) . '">' . esc_html__( 'No geofences yet.', 'bosvesfinder' ) . '</td></tr>';
		} else {
			foreach ( $list as $r ) {
				echo '<tr>';
				echo '<td>' . esc_html( (string) (int) $r['id'] ) . '</td>';
				echo '<td>' . esc_html( $r['name'] ) . '</td>';
				echo '<td>' . esc_html( $r['zone_type'] ) . '</td>';
				$ctr = ( null !== $r['center_lat'] && null !== $r['center_lng'] ) ? $r['center_lat'] . ', ' . $r['center_lng'] : '—';
				echo '<td>' . esc_html( $ctr ) . '</td>';
				echo '<td>' . esc_html( $r['radius_meters'] ? (string) (int) $r['radius_meters'] : '—' ) . '</td>';
				echo '<td>' . ( ! empty( $r['active'] ) ? '✓' : '—' ) . '</td>';
				if ( $can_manage ) {
					echo '<td class="bvf-admin-actions">';
					$eu = add_query_arg(
						array(
							'page'         => 'bvf-geofences',
							'action'       => 'edit',
							'geofence_id'  => (int) $r['id'],
						),
						admin_url( 'admin.php' )
					);
					echo '<a href="' . esc_url( $eu ) . '">' . esc_html__( 'Edit', 'bosvesfinder' ) . '</a> | ';
					$du = wp_nonce_url(
						add_query_arg(
							array(
								'page'         => 'bvf-geofences',
								'action'       => 'delete',
								'geofence_id'  => (int) $r['id'],
							),
							admin_url( 'admin.php' )
						),
						'bvf_delete_geofence_' . (int) $r['id']
					);
					echo '<a href="' . esc_url( $du ) . '" class="bvf-delete-link" onclick="return confirm(\'' . esc_js( __( 'Delete this geofence?', 'bosvesfinder' ) ) . '\');">' . esc_html__( 'Delete', 'bosvesfinder' ) . '</a>';
					echo '</td>';
				}
				echo '</tr>';
			}
		}
		echo '</tbody></table></div>';
	}

	/**
	 * Trip & alert summaries with export.
	 */
	public function render_reports() {
		if ( ! current_user_can( BVF_Roles::CAP_VIEW_FLEET ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'bosvesfinder' ) );
		}

		list( $from, $to ) = $this->get_report_date_range_from_get();

		global $wpdb;
		$trips   = $this->t( 'trips' );
		$vessels = $this->t( 'vessels' );
		$logs    = $this->t( 'location_logs' );
		$fuel    = $this->t( 'fuel_logs' );

		$sql = "SELECT t.*, v.name AS vessel_name,
			(SELECT COUNT(*) FROM {$logs} l WHERE l.trip_id = t.id) AS point_count,
			(SELECT COALESCE(SUM(f.fuel_consumed_litres),0) FROM {$fuel} f WHERE f.trip_id = t.id) AS fuel_sum
			FROM {$trips} t
			INNER JOIN {$vessels} v ON v.id = t.vessel_id
			WHERE DATE(COALESCE(t.started_at, t.created_at)) BETWEEN %s AND %s
			ORDER BY t.id DESC LIMIT 250";

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $from, $to ), ARRAY_A );

		$base_url = add_query_arg(
			array(
				'page'      => 'bvf-reports',
				'date_from' => $from,
				'date_to'   => $to,
			),
			admin_url( 'admin.php' )
		);

		$nonce_trips  = wp_create_nonce( 'bvf_export_trips' );
		$nonce_alerts = wp_create_nonce( 'bvf_export_alerts' );

		echo '<div class="wrap bvf-reports-wrap">';
		echo '<h1>' . esc_html__( 'Reports', 'bosvesfinder' ) . '</h1>';

		echo '<div class="bvf-admin-card"><form method="get" class="bvf-report-filters">';
		echo '<input type="hidden" name="page" value="bvf-reports" />';
		echo '<p><label>' . esc_html__( 'From', 'bosvesfinder' ) . ' <input type="date" name="date_from" value="' . esc_attr( $from ) . '" /></label> ';
		echo '<label>' . esc_html__( 'To', 'bosvesfinder' ) . ' <input type="date" name="date_to" value="' . esc_attr( $to ) . '" /></label> ';
		submit_button( __( 'Apply', 'bosvesfinder' ), 'secondary', 'submit', false );
		echo '</p></form>';

		echo '<p class="bvf-admin-actions">';
		echo '<a class="button button-primary" href="' . esc_url( add_query_arg( array( 'bvf_export' => 'trips', '_wpnonce' => $nonce_trips ), $base_url ) ) . '">' . esc_html__( 'Export trips CSV', 'bosvesfinder' ) . '</a> ';
		echo '<a class="button" href="' . esc_url( add_query_arg( array( 'bvf_export' => 'alerts', '_wpnonce' => $nonce_alerts ), $base_url ) ) . '">' . esc_html__( 'Export alerts CSV', 'bosvesfinder' ) . '</a> ';
		echo '<button type="button" class="button" onclick="window.print();">' . esc_html__( 'Print / Save as PDF', 'bosvesfinder' ) . '</button>';
		echo '</p></div>';

		echo '<h2 class="title">' . esc_html__( 'Trips in range', 'bosvesfinder' ) . '</h2>';
		echo '<table class="widefat striped"><thead><tr>';
		echo '<th>ID</th><th>' . esc_html__( 'Vessel', 'bosvesfinder' ) . '</th><th>' . esc_html__( 'Captain', 'bosvesfinder' ) . '</th>';
		echo '<th>' . esc_html__( 'Status', 'bosvesfinder' ) . '</th><th>' . esc_html__( 'Points', 'bosvesfinder' ) . '</th>';
		echo '<th>' . esc_html__( 'Track NM', 'bosvesfinder' ) . '</th><th>' . esc_html__( 'Fuel out L', 'bosvesfinder' ) . '</th>';
		echo '<th>' . esc_html__( 'Started', 'bosvesfinder' ) . '</th>';
		echo '</tr></thead><tbody>';

		if ( empty( $rows ) ) {
			echo '<tr><td colspan="8">' . esc_html__( 'No trips in this date range.', 'bosvesfinder' ) . '</td></tr>';
		} else {
			foreach ( $rows as $r ) {
				$nm = BVF_Geofence::trip_distance_nm( (int) $r['id'] );
				echo '<tr>';
				echo '<td>' . esc_html( (string) (int) $r['id'] ) . '</td>';
				echo '<td>' . esc_html( $r['vessel_name'] ) . '</td>';
				echo '<td>' . esc_html( $this->user_display_name( (int) $r['captain_user_id'] ) ) . '</td>';
				echo '<td>' . esc_html( $r['status'] ) . '</td>';
				echo '<td>' . esc_html( (string) (int) $r['point_count'] ) . '</td>';
				echo '<td>' . esc_html( (string) $nm ) . '</td>';
				echo '<td>' . esc_html( (string) $r['fuel_sum'] ) . '</td>';
				echo '<td>' . esc_html( $r['started_at'] ? $r['started_at'] : $r['created_at'] ) . '</td>';
				echo '</tr>';
			}
		}
		echo '</tbody></table>';

		echo '<style>@media print { #wpadminbar, #adminmenumain, #adminmenuback, #screen-meta, #screen-meta-links, .update-nag, .notice { display: none !important; } #wpcontent, #wpbody { margin-left: 0 !important; padding-left: 12px !important; } .bvf-report-filters, .bvf-admin-actions { display: none !important; } }</style>';
		echo '</div>';
	}

	/**
	 * Notifications & alert email toggles.
	 */
	public function render_settings() {
		if ( ! current_user_can( BVF_Roles::CAP_MANAGE_FLEET ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'bosvesfinder' ) );
		}

		$emails  = (string) get_option( 'bvf_ops_notification_emails', '' );
		$mail_gf = (string) get_option( 'bvf_email_geofence', '0' ) === '1';
		$mail_sl = (string) get_option( 'bvf_email_signal_loss', '0' ) === '1';

		echo '<div class="wrap"><h1>' . esc_html__( 'BOSVesFinder settings', 'bosvesfinder' ) . '</h1>';
		$this->maybe_notice_saved();
		echo '<div class="bvf-admin-card bvf-admin-form"><form method="post">';
		wp_nonce_field( 'bvf_admin_save_settings', '_bvf_admin_nonce' );
		echo '<input type="hidden" name="bvf_admin_action" value="save_settings" />';
		echo '<table class="form-table"><tbody>';
		echo '<tr><th scope="row"><label for="bvf-set-mail">' . esc_html__( 'Operations emails', 'bosvesfinder' ) . '</label></th><td>';
		echo '<textarea name="bvf_ops_notification_emails" id="bvf-set-mail" class="large-text" rows="3" placeholder="' . esc_attr( get_bloginfo( 'admin_email' ) ) . '">' . esc_textarea( $emails ) . '</textarea>';
		echo '<p class="description">' . esc_html__( 'One address per line, or comma-separated. Used for SOS (always) and optional geofence/signal alerts. If empty, the site admin email is used.', 'bosvesfinder' ) . '</p></td></tr>';
		echo '<tr><th scope="row">' . esc_html__( 'Email on geofence violation', 'bosvesfinder' ) . '</th><td>';
		echo '<label><input type="checkbox" name="bvf_email_geofence" value="1" ' . checked( $mail_gf, true, false ) . ' /> ';
		esc_html_e( 'Send email when a geofence alert is created', 'bosvesfinder' );
		echo '</label></td></tr>';
		echo '<tr><th scope="row">' . esc_html__( 'Email on signal loss', 'bosvesfinder' ) . '</th><td>';
		echo '<label><input type="checkbox" name="bvf_email_signal_loss" value="1" ' . checked( $mail_sl, true, false ) . ' /> ';
		esc_html_e( 'Send email when the cron job records a signal-loss alert', 'bosvesfinder' );
		echo '</label><p class="description">' . esc_html__( 'Stale threshold uses the same window as live map offline detection (filter: bvf_signal_loss_seconds). Cron runs every 15 minutes.', 'bosvesfinder' ) . '</p></td></tr>';
		echo '</tbody></table>';
		submit_button( __( 'Save settings', 'bosvesfinder' ) );
		echo '</form>';
		echo '<p class="description" style="margin-top:1.5rem">' . esc_html__( 'Uninstall: deleting the plugin from WordPress removes BVF options, transients, and the signal-loss cron. Custom tables and BVF user roles are kept unless you define BVF_UNINSTALL_DELETE_DATA as true in wp-config.php before uninstalling.', 'bosvesfinder' ) . '</p>';
		echo '</div></div>';
	}

	/**
	 * Environment checks for deployment / support.
	 */
	public function render_status() {
		if ( ! current_user_can( BVF_Roles::CAP_VIEW_FLEET ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'bosvesfinder' ) );
		}

		global $wpdb;
		$prefix = $wpdb->prefix;

		$core_tables = array(
			'bvf_vessels',
			'bvf_trips',
			'bvf_location_logs',
			'bvf_fuel_logs',
			'bvf_crew',
			'bvf_trip_crew',
			'bvf_alerts',
			'bvf_geofences',
		);

		$missing = array();
		foreach ( $core_tables as $suffix ) {
			$like = $prefix . $suffix;
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) );
			if ( $like !== $found ) {
				$missing[] = $suffix;
			}
		}

		$cron_next = wp_next_scheduled( 'bvf_check_signal_loss' );
		$cron_txt  = $cron_next
			? esc_html(
				sprintf(
					/* translators: %s: localized date/time */
					__( 'Next run: %s', 'bosvesfinder' ),
					wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $cron_next )
				)
			)
			: esc_html__( 'Not scheduled (visit the site front end once or re-activate the plugin).', 'bosvesfinder' );

		echo '<div class="wrap"><h1>' . esc_html__( 'BOSVesFinder — System status', 'bosvesfinder' ) . '</h1>';
		echo '<div class="bvf-admin-card"><table class="widefat striped"><tbody>';
		$this->status_row( __( 'Plugin version', 'bosvesfinder' ), esc_html( BVF_VERSION ) );
		$this->status_row( __( 'PHP', 'bosvesfinder' ), esc_html( PHP_VERSION ) );
		$this->status_row( __( 'WordPress', 'bosvesfinder' ), esc_html( get_bloginfo( 'version' ) ) );
		$this->status_row(
			__( 'HTTPS (admin)', 'bosvesfinder' ),
			is_ssl()
				? '<span class="bvf-badge bvf-badge--active">OK</span>'
				: '<span class="bvf-badge bvf-badge--pending">' . esc_html__( 'Off', 'bosvesfinder' ) . '</span>'
		);
		$this->status_row(
			__( 'Database tables', 'bosvesfinder' ),
			empty( $missing )
				? '<span class="bvf-badge bvf-badge--active">' . esc_html__( 'All present', 'bosvesfinder' ) . '</span>'
				: '<span class="bvf-badge bvf-badge--critical">' . esc_html( implode( ', ', $missing ) ) . '</span>'
		);
		$this->status_row( __( 'Signal-loss cron', 'bosvesfinder' ), $cron_txt );
		$this->status_row(
			__( 'REST API base', 'bosvesfinder' ),
			'<code>' . esc_html( rest_url( 'bosvesfinder/v1/' ) ) . '</code>'
		);
		$this->status_row(
			__( 'List trips (GET)', 'bosvesfinder' ),
			'<code>' . esc_html( rest_url( 'bosvesfinder/v1/trips?per_page=5' ) ) . '</code>'
		);
		echo '</tbody></table></div></div>';
	}

	/**
	 * @param string $label Translated label.
	 * @param string $value HTML (caller escapes where needed).
	 */
	private function status_row( $label, $value ) {
		echo '<tr><th scope="row" style="width:14rem">' . esc_html( $label ) . '</th><td>' . $value . '</td></tr>';
	}
}
