<?php
/**
 * Scheduled tasks (signal loss, etc.).
 *
 * @package BosVesFinder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cron registration and signal-loss checks for active trips.
 */
class BVF_Cron {

	public const HOOK_SIGNAL = 'bvf_check_signal_loss';

	/**
	 * Register cron hook handler.
	 */
	public static function init() {
		add_action( self::HOOK_SIGNAL, array( __CLASS__, 'run_signal_loss_check' ) );
		add_action( 'init', array( __CLASS__, 'maybe_schedule' ), 20 );
	}

	/**
	 * Ensure event exists after plugin updates without re-activation.
	 */
	public static function maybe_schedule() {
		if ( ! wp_next_scheduled( self::HOOK_SIGNAL ) ) {
			self::activate_schedule();
		}
	}

	/**
	 * Schedule recurring event (on plugin activation).
	 */
	public static function activate_schedule() {
		if ( ! wp_next_scheduled( self::HOOK_SIGNAL ) ) {
			wp_schedule_event( time() + 120, 'bvf_15min', self::HOOK_SIGNAL );
		}
	}

	/**
	 * Clear scheduled event (on plugin deactivation).
	 */
	public static function clear_schedule() {
		wp_clear_scheduled_hook( self::HOOK_SIGNAL );
	}

	/**
	 * Find active trips with stale GPS and record alerts.
	 */
	public static function run_signal_loss_check() {
		global $wpdb;
		$trips = $wpdb->prefix . 'bvf_trips';
		$logs  = $wpdb->prefix . 'bvf_location_logs';
		$al    = $wpdb->prefix . 'bvf_alerts';

		$threshold = (int) apply_filters( 'bvf_signal_loss_seconds', 600 );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$active = $wpdb->get_results(
			"SELECT id, vessel_id, captain_user_id, started_at FROM {$trips} WHERE status = 'active'",
			ARRAY_A
		);
		if ( empty( $active ) ) {
			return;
		}

		$now_mysql = current_time( 'mysql' );

		foreach ( $active as $row ) {
			$trip_id   = (int) $row['id'];
			$vessel_id = (int) $row['vessel_id'];
			$user_id   = (int) $row['captain_user_id'];

			$last_log = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT MAX(created_at) FROM {$logs} WHERE trip_id = %d",
					$trip_id
				)
			);

			$stale = false;
			if ( $last_log ) {
				$ts = strtotime( get_gmt_from_date( $last_log ) );
				if ( false !== $ts && ( time() - $ts ) > $threshold ) {
					$stale = true;
				}
			} elseif ( ! empty( $row['started_at'] ) ) {
				$ts = strtotime( get_gmt_from_date( $row['started_at'] ) );
				if ( false !== $ts && ( time() - $ts ) > $threshold ) {
					$stale = true;
				}
			}

			if ( ! $stale ) {
				continue;
			}

			if ( self::has_recent_alert( $trip_id, 'signal_loss', 1800 ) ) {
				continue;
			}

			$payload = wp_json_encode(
				array(
					'reason'     => 'no_recent_position',
					'threshold'  => $threshold,
					'last_log_at' => $last_log,
				)
			);

			$wpdb->insert(
				$al,
				array(
					'alert_type' => 'signal_loss',
					'severity'   => 'warning',
					'trip_id'    => $trip_id,
					'vessel_id'  => $vessel_id,
					'user_id'    => $user_id,
					'payload'    => $payload,
					'created_at' => $now_mysql,
				),
				array( '%s', '%s', '%d', '%d', '%d', '%s', '%s' )
			);

			$alert_id = (int) $wpdb->insert_id;
			do_action( 'bvf_alert_created', $alert_id, 'signal_loss', $trip_id, $vessel_id );

			if ( get_option( 'bvf_email_signal_loss' ) === '1' ) {
				BVF_Notifications::notify_generic_alert(
					$alert_id,
					__( 'Signal loss / stale GPS', 'bosvesfinder' ),
					$trip_id,
					$vessel_id
				);
			}
		}
	}

	/**
	 * @param int    $trip_id Trip ID.
	 * @param string $type    Alert type slug.
	 * @param int    $window  Seconds lookback.
	 */
	private static function has_recent_alert( $trip_id, $type, $window ) {
		global $wpdb;
		$al    = $wpdb->prefix . 'bvf_alerts';
		$since = gmdate( 'Y-m-d H:i:s', time() - $window );
		$c     = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$al} WHERE trip_id = %d AND alert_type = %s AND created_at >= %s",
				$trip_id,
				$type,
				$since
			)
		);
		return (int) $c > 0;
	}
}
