<?php
/**
 * Custom roles and capabilities.
 *
 * @package BosVesFinder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers BVF roles and capability grants.
 */
class BVF_Roles {

	const ROLE_SYSTEM_ADMIN    = 'bvf_system_administrator';
	const ROLE_OPS_MANAGER     = 'bvf_operations_manager';
	const ROLE_CAPTAIN         = 'bvf_captain';
	const ROLE_VIEWER          = 'bvf_viewer';

	const CAP_VIEW_FLEET       = 'bvf_view_fleet';
	const CAP_SUBMIT_TRACKING  = 'bvf_submit_tracking';
	const CAP_MANAGE_FLEET     = 'bvf_manage_fleet';
	const CAP_MANAGE_SETTINGS  = 'bvf_manage_settings';

	/**
	 * Add roles and ensure administrators retain full BVF access.
	 */
	public static function install_roles() {
		self::register_caps_for_admin();

		add_role(
			self::ROLE_VIEWER,
			__( 'BVF Viewer', 'bosvesfinder' ),
			array(
				'read'                 => true,
				self::CAP_VIEW_FLEET   => true,
			)
		);

		add_role(
			self::ROLE_CAPTAIN,
			__( 'BVF Captain', 'bosvesfinder' ),
			array(
				'read'                    => true,
				self::CAP_VIEW_FLEET      => true,
				self::CAP_SUBMIT_TRACKING => true,
			)
		);

		add_role(
			self::ROLE_OPS_MANAGER,
			__( 'BVF Operations Manager', 'bosvesfinder' ),
			array(
				'read'                    => true,
				self::CAP_VIEW_FLEET      => true,
				self::CAP_SUBMIT_TRACKING => true,
				self::CAP_MANAGE_FLEET    => true,
			)
		);

		add_role(
			self::ROLE_SYSTEM_ADMIN,
			__( 'BVF System Administrator', 'bosvesfinder' ),
			array(
				'read'                    => true,
				self::CAP_VIEW_FLEET      => true,
				self::CAP_SUBMIT_TRACKING => true,
				self::CAP_MANAGE_FLEET    => true,
				self::CAP_MANAGE_SETTINGS => true,
			)
		);
	}

	/**
	 * WordPress Administrators get all BVF capabilities.
	 */
	private static function register_caps_for_admin() {
		$role = get_role( 'administrator' );
		if ( ! $role ) {
			return;
		}
		$caps = array(
			self::CAP_VIEW_FLEET,
			self::CAP_SUBMIT_TRACKING,
			self::CAP_MANAGE_FLEET,
			self::CAP_MANAGE_SETTINGS,
		);
		foreach ( $caps as $cap ) {
			$role->add_cap( $cap );
		}
	}

	/**
	 * Remove custom roles (used from uninstall only).
	 */
	public static function remove_roles() {
		remove_role( self::ROLE_SYSTEM_ADMIN );
		remove_role( self::ROLE_OPS_MANAGER );
		remove_role( self::ROLE_CAPTAIN );
		remove_role( self::ROLE_VIEWER );

		$role = get_role( 'administrator' );
		if ( $role ) {
			foreach ( array( self::CAP_VIEW_FLEET, self::CAP_SUBMIT_TRACKING, self::CAP_MANAGE_FLEET, self::CAP_MANAGE_SETTINGS ) as $cap ) {
				$role->remove_cap( $cap );
			}
		}
	}
}
