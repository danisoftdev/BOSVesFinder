<?php
/**
 * Plugin deactivation (roles and data are preserved).
 *
 * @package BosVesFinder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Deactivation cleanup.
 */
class BVF_Deactivator {

	/**
	 * Flush rewrite rules; keep DB and roles for upgrades.
	 */
	public static function deactivate() {
		BVF_Cron::clear_schedule();
		flush_rewrite_rules();
	}
}
