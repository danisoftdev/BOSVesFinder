<?php
/**
 * Activation: database tables and roles.
 *
 * @package BosVesFinder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Runs schema creation and role setup.
 */
class BVF_Activator {

	/**
	 * Activate plugin.
	 */
	public static function activate() {
		self::create_tables();
		BVF_Roles::install_roles();
		self::default_options();
		BVF_Cron::activate_schedule();
		flush_rewrite_rules();
	}

	/**
	 * Default plugin options (Phase 3 notifications).
	 */
	private static function default_options() {
		add_option( 'bvf_email_geofence', '0', '', 'no' );
		add_option( 'bvf_email_signal_loss', '0', '', 'no' );
	}

	/**
	 * Create custom tables with dbDelta.
	 */
	private static function create_tables() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();
		$prefix          = $wpdb->prefix;

		$sql = array();

		$sql[] = "CREATE TABLE {$prefix}bvf_vessels (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			name varchar(191) NOT NULL DEFAULT '',
			external_id varchar(64) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT 'active',
			assigned_captain_user_id bigint(20) unsigned NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY status (status),
			KEY assigned_captain (assigned_captain_user_id)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE {$prefix}bvf_trips (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			vessel_id bigint(20) unsigned NOT NULL,
			captain_user_id bigint(20) unsigned NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'pending',
			origin_label text NULL,
			destination_label text NULL,
			started_at datetime NULL,
			ended_at datetime NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY vessel_status (vessel_id,status),
			KEY captain_status (captain_user_id,status)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE {$prefix}bvf_location_logs (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			trip_id bigint(20) unsigned NOT NULL,
			user_id bigint(20) unsigned NOT NULL,
			latitude decimal(10,7) NOT NULL,
			longitude decimal(10,7) NOT NULL,
			accuracy_m float NULL,
			speed_knots float NULL,
			heading_degrees float NULL,
			altitude_m float NULL,
			battery_percent tinyint(4) NULL,
			source varchar(32) NOT NULL DEFAULT 'mobile',
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY trip_created (trip_id,created_at),
			KEY user_created (user_id,created_at)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE {$prefix}bvf_fuel_logs (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			trip_id bigint(20) unsigned NOT NULL,
			user_id bigint(20) unsigned NOT NULL,
			fuel_loaded_litres decimal(12,3) NULL,
			fuel_consumed_litres decimal(12,3) NULL,
			notes text NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY trip_id (trip_id)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE {$prefix}bvf_crew (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			wp_user_id bigint(20) unsigned NULL,
			display_name varchar(191) NOT NULL DEFAULT '',
			role_slug varchar(64) NOT NULL DEFAULT '',
			vessel_id bigint(20) unsigned NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY vessel_id (vessel_id),
			KEY wp_user (wp_user_id)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE {$prefix}bvf_trip_crew (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			trip_id bigint(20) unsigned NOT NULL,
			crew_id bigint(20) unsigned NOT NULL,
			onboard_confirmed tinyint(1) NOT NULL DEFAULT 0,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY trip_crew (trip_id,crew_id)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE {$prefix}bvf_alerts (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			alert_type varchar(64) NOT NULL DEFAULT '',
			severity varchar(20) NOT NULL DEFAULT 'info',
			trip_id bigint(20) unsigned NULL,
			vessel_id bigint(20) unsigned NULL,
			user_id bigint(20) unsigned NULL,
			payload longtext NULL,
			acknowledged_at datetime NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY severity (severity),
			KEY trip_id (trip_id),
			KEY vessel_id (vessel_id)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE {$prefix}bvf_geofences (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			name varchar(191) NOT NULL DEFAULT '',
			zone_type varchar(32) NOT NULL DEFAULT 'operational',
			center_lat decimal(10,7) NULL,
			center_lng decimal(10,7) NULL,
			radius_meters int(11) NULL,
			geojson longtext NULL,
			active tinyint(1) NOT NULL DEFAULT 1,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY active (active)
		) {$charset_collate};";

		foreach ( $sql as $statement ) {
			dbDelta( $statement );
		}
	}
}
