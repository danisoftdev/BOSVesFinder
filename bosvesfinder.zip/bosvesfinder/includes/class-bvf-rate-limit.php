<?php
/**
 * Simple per-user sliding-window rate limits for REST write endpoints.
 *
 * @package BosVesFinder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Uses transients (object cache when available).
 */
class BVF_Rate_Limit {

	/**
	 * @param string $bucket     Logical limiter name.
	 * @param int    $user_id    WordPress user ID.
	 * @param int    $max        Max actions per window.
	 * @param int    $window_sec Window length in seconds.
	 * @return true|WP_Error
	 */
	public static function allow_or_error( $bucket, $user_id, $max, $window_sec ) {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 || $max < 1 || $window_sec < 1 ) {
			return true;
		}

		$key = 'bvf_rl_' . sanitize_key( $bucket ) . '_' . $user_id;
		$now = time();
		$row = get_transient( $key );

		if ( ! is_array( $row ) || empty( $row['window_end'] ) || $now >= (int) $row['window_end'] ) {
			$row = array(
				'count'      => 0,
				'window_end' => $now + $window_sec,
			);
		}

		if ( (int) $row['count'] >= $max ) {
			return new WP_Error(
				'bvf_rate_limit',
				__( 'Too many requests. Please wait a moment and try again.', 'bosvesfinder' ),
				array( 'status' => 429 )
			);
		}

		$row['count'] = (int) $row['count'] + 1;
		$ttl          = max( 1, (int) $row['window_end'] - $now );
		set_transient( $key, $row, $ttl );

		return true;
	}
}
