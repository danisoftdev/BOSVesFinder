<?php
/**
 * Short-lived transient cache for fleet live JSON (reduces DB load under poll).
 *
 * @package BosVesFinder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Invalidated when positions change or active trips complete.
 */
class BVF_Fleet_Cache {

	public const TRANSIENT_KEY = 'bvf_fleet_live_v1';

	/**
	 * @return array<int,array<string,mixed>>|false
	 */
	public static function get() {
		$data = get_transient( self::TRANSIENT_KEY );
		return is_array( $data ) ? $data : false;
	}

	/**
	 * @param array<int,array<string,mixed>> $payload Serializable fleet rows.
	 */
	public static function set( array $payload ) {
		$ttl = (int) apply_filters( 'bvf_fleet_live_cache_ttl', 12 );
		$ttl = max( 3, min( 120, $ttl ) );
		set_transient( self::TRANSIENT_KEY, $payload, $ttl );
	}

	public static function bust() {
		delete_transient( self::TRANSIENT_KEY );
	}
}
