<?php
/**
 * Plugin Name:       BOSVesFinder
 * Plugin URI:        https://benmarine-offshore.example/bosvesfinder
 * Description:       Fleet intelligence: GPS, geofences, alerts & email, trip REST, reports/CSV, caching, heatmaps, uninstall cleanup, WP admin.
 * Version:           1.4.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Benmarine Offshore Services
 * License:           GPL-2.0-or-later
 * Text Domain:       bosvesfinder
 *
 * @package BosVesFinder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Custom cron intervals.
 *
 * @param array<string,array<string,mixed>> $schedules Schedules.
 * @return array<string,array<string,mixed>>
 */
function bvf_cron_schedules( $schedules ) {
	if ( ! isset( $schedules['bvf_15min'] ) ) {
		$schedules['bvf_15min'] = array(
			'interval' => 900,
			/* translators: cron schedule label */
			'display'  => __( 'Every 15 minutes (BOSVesFinder)', 'bosvesfinder' ),
		);
	}
	return $schedules;
}

add_filter( 'cron_schedules', 'bvf_cron_schedules' );

define( 'BVF_VERSION', '1.4.0' );
define( 'BVF_PLUGIN_FILE', __FILE__ );
define( 'BVF_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'BVF_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'BVF_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

require_once BVF_PLUGIN_DIR . 'includes/class-bvf-roles.php';
require_once BVF_PLUGIN_DIR . 'includes/class-bvf-notifications.php';
require_once BVF_PLUGIN_DIR . 'includes/class-bvf-geofence.php';
require_once BVF_PLUGIN_DIR . 'includes/class-bvf-cron.php';
require_once BVF_PLUGIN_DIR . 'includes/class-bvf-fleet-cache.php';
require_once BVF_PLUGIN_DIR . 'includes/class-bvf-rate-limit.php';
require_once BVF_PLUGIN_DIR . 'includes/class-bvf-activator.php';
require_once BVF_PLUGIN_DIR . 'includes/class-bvf-deactivator.php';
require_once BVF_PLUGIN_DIR . 'includes/class-bvf-rest.php';
require_once BVF_PLUGIN_DIR . 'includes/class-bvf-admin.php';
require_once BVF_PLUGIN_DIR . 'includes/class-bvf-plugin.php';

/**
 * Runs on plugin activation.
 */
function bvf_activate() {
	BVF_Activator::activate();
}

/**
 * Runs on plugin deactivation.
 */
function bvf_deactivate() {
	BVF_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'bvf_activate' );
register_deactivation_hook( __FILE__, 'bvf_deactivate' );

/**
 * Bootstrap plugin.
 */
function bvf_run() {
	$plugin = new BVF_Plugin();
	$plugin->run();
}

bvf_run();
