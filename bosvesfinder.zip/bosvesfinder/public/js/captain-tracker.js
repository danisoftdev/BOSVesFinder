(function () {
	'use strict';

	function $(sel, root) {
		return (root || document).querySelector(sel);
	}

	function initPanel(root) {
		var cfg = window.bvfCaptain;
		if (!cfg || !cfg.restBase) {
			return;
		}

		var tripId = null;
		var watchId = null;
		var intervalId = null;
		var tracking = false;

		var statusEl = $('.bvf-captain__status', root);
		var msgEl = $('.bvf-captain__msg', root);
		var btnStart = $('.bvf-captain__start', root);
		var btnStop = $('.bvf-captain__stop', root);
		var btnSos = $('.bvf-captain__sos', root);

		function setMsg(text, isErr) {
			if (!msgEl) {
				return;
			}
			msgEl.textContent = text || '';
			msgEl.classList.toggle('bvf-captain__msg--err', !!isErr);
		}

		function api(path, opts) {
			opts = opts || {};
			opts.credentials = 'same-origin';
			opts.headers = opts.headers || {};
			opts.headers['X-WP-Nonce'] = cfg.nonce;
			if (opts.body && typeof opts.body === 'object' && !(opts.body instanceof FormData)) {
				opts.headers['Content-Type'] = 'application/json';
				opts.body = JSON.stringify(opts.body);
			}
			return fetch(cfg.restBase + path, opts).then(function (r) {
				return r.text().then(function (text) {
					var j = null;
					if (text) {
						try {
							j = JSON.parse(text);
						} catch (e) {
							j = null;
						}
					}
					if (!r.ok) {
						var err =
							(j && (j.message || (j.data && j.data.message))) ||
							'Request failed (' + r.status + ')';
						throw new Error(err);
					}
					if (r.status === 204 || text === '') {
						return null;
					}
					return j;
				});
			});
		}

		function postPosition(pos) {
			if (!tripId || !pos || !pos.coords) {
				return;
			}
			var c = pos.coords;
			var body = {
				latitude: c.latitude,
				longitude: c.longitude,
				accuracy_m: c.accuracy != null ? c.accuracy : undefined,
				speed_knots:
					c.speed != null && !isNaN(c.speed) && c.speed >= 0
						? c.speed * 1.94384
						: undefined,
				heading_degrees: c.heading != null && !isNaN(c.heading) ? c.heading : undefined,
				altitude_m: c.altitude != null ? c.altitude : undefined,
				source: 'mobile',
			};
			api('trips/' + tripId + '/positions', { method: 'POST', body: body }).catch(function (e) {
				setMsg(e.message || 'Sync failed', true);
			});
		}

		function startTracking() {
			if (!tripId || tracking) {
				return;
			}
			if (!navigator.geolocation) {
				setMsg('Geolocation is not available in this browser.', true);
				return;
			}
			tracking = true;
			btnStart.disabled = true;
			btnStop.disabled = false;
			setMsg('Tracking…');

			function onPos(pos) {
				postPosition(pos);
			}

			watchId = navigator.geolocation.watchPosition(onPos, function (err) {
				setMsg(err && err.message ? err.message : 'GPS error', true);
			}, {
				enableHighAccuracy: true,
				maximumAge: 10000,
				timeout: 20000,
			});

			intervalId = window.setInterval(function () {
				navigator.geolocation.getCurrentPosition(onPos, function () {}, {
					enableHighAccuracy: true,
					maximumAge: 5000,
					timeout: 15000,
				});
			}, cfg.intervalMs || 30000);
		}

		function stopTracking() {
			tracking = false;
			btnStart.disabled = false;
			btnStop.disabled = true;
			if (watchId != null && navigator.geolocation) {
				navigator.geolocation.clearWatch(watchId);
				watchId = null;
			}
			if (intervalId) {
				window.clearInterval(intervalId);
				intervalId = null;
			}
			setMsg('Tracking stopped.');
		}

		function loadActiveTrip() {
			setMsg(cfg.i18n && cfg.i18n.loading ? cfg.i18n.loading : '');
			api('trips/mine/active')
				.then(function (data) {
					if (!data || !data.id) {
						tripId = null;
						if (statusEl) {
							statusEl.textContent =
								cfg.i18n && cfg.i18n.noTrip
									? cfg.i18n.noTrip
									: 'No active trip. Ask operations to start one for you.';
						}
						btnStart.disabled = true;
						btnStop.disabled = true;
						if (btnSos) {
							btnSos.disabled = true;
						}
						return;
					}
					tripId = data.id;
					if (statusEl) {
						statusEl.textContent =
							(cfg.i18n && cfg.i18n.tripLabel ? cfg.i18n.tripLabel : 'Active trip') +
							' #' +
							tripId +
							(data.vessel_id ? ' · vessel ' + data.vessel_id : '');
					}
					btnStart.disabled = false;
					btnStop.disabled = true;
					if (btnSos) {
						btnSos.disabled = false;
					}
					setMsg('');
				})
				.catch(function (e) {
					if (btnSos) {
						btnSos.disabled = true;
					}
					setMsg(e.message || 'Could not load trip', true);
				});
		}

		btnStart.addEventListener('click', startTracking);
		btnStop.addEventListener('click', stopTracking);

		if (btnSos) {
			btnSos.addEventListener('click', function () {
				if (!tripId) {
					setMsg(cfg.i18n && cfg.i18n.noTrip ? cfg.i18n.noTrip : 'No active trip.', true);
					return;
				}
				if (!window.confirm(cfg.i18n && cfg.i18n.sosConfirm ? cfg.i18n.sosConfirm : 'Send SOS alert to operations?')) {
					return;
				}
				api('alerts/sos', { method: 'POST', body: { trip_id: tripId } })
					.then(function () {
						setMsg(cfg.i18n && cfg.i18n.sosSent ? cfg.i18n.sosSent : 'SOS recorded. Stay safe.');
					})
					.catch(function (e) {
						setMsg(e.message || 'SOS failed', true);
					});
			});
		}

		loadActiveTrip();
	}

	function boot() {
		document.querySelectorAll('.bvf-captain').forEach(function (root) {
			if (root.dataset.bvfCaptainInit === '1') {
				return;
			}
			root.dataset.bvfCaptainInit = '1';
			initPanel(root);
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
