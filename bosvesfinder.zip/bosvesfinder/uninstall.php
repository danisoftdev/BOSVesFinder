<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * Default: clears BVF options, rate-limit/fleet transients, and scheduled cron.
 * Full data removal (custom tables + roles): define BVF_UNINSTALL_DELETE_DATA as true in wp-config.php before uninstalling.
 *
 * @package BosVesFinder
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

wp_clear_scheduled_hook( 'bvf_check_signal_loss' );

$option_names = array(
	'bvf_ops_notification_emails',
	'bvf_email_geofence',
	'bvf_email_signal_loss',
);

foreach ( $option_names as $name ) {
	delete_option( $name );
}

// Plugin transients (fleet cache, rate limits).
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
$wpdb->query(
	"DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_bvf_%' OR option_name LIKE '_transient_timeout_bvf_%'"
);

if ( defined( 'BVF_UNINSTALL_DELETE_DATA' ) && BVF_UNINSTALL_DELETE_DATA ) {
	$tables = array(
		'bvf_location_logs',
		'bvf_fuel_logs',
		'bvf_trip_crew',
		'bvf_alerts',
		'bvf_trips',
		'bvf_crew',
		'bvf_vessels',
		'bvf_geofences',
	);
	foreach ( $tables as $suffix ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
		$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$suffix}" );
	}

	if ( file_exists( __DIR__ . '/includes/class-bvf-roles.php' ) ) {
		require_once __DIR__ . '/includes/class-bvf-roles.php';
		if ( class_exists( 'BVF_Roles' ) ) {
			BVF_Roles::remove_roles();
		}
	}
}
